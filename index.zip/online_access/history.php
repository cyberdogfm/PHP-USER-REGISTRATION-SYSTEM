<?php
include 'configure.php';
if(! empty($_SESSION['user']))
		{
		

?>


<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" href="../images/favicon.ico">

	<title>History | Bytes Ledger Trade</title>

	<!-- Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,700&amp;subset=latin-ext" rel="stylesheet">

	<!-- CSS - REQUIRED - START -->
	<!-- Batch Icons -->
	<link rel="stylesheet" href="assets/fonts/batch-icons/css/batch-icons.css">
	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="assets/css/bootstrap/bootstrap.min.css">
	<!-- Material Design Bootstrap -->
	<link rel="stylesheet" href="assets/css/bootstrap/mdb.min.css">
	<!-- Custom Scrollbar -->
	<link rel="stylesheet" href="assets/plugins/custom-scrollbar/jquery.mCustomScrollbar.min.css">
	<!-- Hamburger Menu -->
	<link rel="stylesheet" href="assets/css/hamburgers/hamburgers.css">

	<!-- CSS - REQUIRED - END -->

	<!-- CSS - OPTIONAL - START -->
	<!-- Font Awesome -->
	<link rel="stylesheet" href="assets/fonts/font-awesome/css/font-awesome.min.css">
	<!-- JVMaps -->
	<link rel="stylesheet" href="assets/plugins/jvmaps/jqvmap.min.css">
	<!-- CSS - OPTIONAL - END -->

	<!-- QuillPro Styles -->
	<link rel="stylesheet" href="assets/css/quillpro/quillpro.css">
	<style type="text/css">
	.nosamepass {
  display: none;
}
	</style>
	



</head>

<body>

	<div class="container-fluid">
		<div class="row">
			<nav id="sidebar" class="px-0 bg-dark bg-gradient sidebar">
				<ul class="nav nav-pills flex-column">
					<li class="logo-nav-item">
						<a class="navbar-brand" href="#">
							<!-- <img src="assets/img/logo-white.png" width="145" height="32.3" alt="QuillPro">-->
						</a>

					</li>
					
					<li class="nav-item">
						<a class="nav-link active" href="profile.php">
							<i class="batch-icon batch-icon-browser-alt"></i>
							Dashboard <span class="sr-only">(<?php echo $_SESSION['acctype'];?>)</span>
						</a>
					</li>
					<!--
						<?php
						/*
	if($row['act']=='Inactive')
	{
		?>
		
			
<a href="#"target="_blank">					<li class="nav-item">
						<a class="nav-link"href="#"target="_blank">
							<i class="batch-icon batch-icon-settings"></i>
							Account Onhold
						</a>

<?php
	}
	else
	{
	?>	
					<li class="nav-item">
						<a class="nav-link" href="transfer-funds.php"target="_blank">
							<i class="batch-icon batch-icon-settings"></i>
							Withdraw
						</a>
						</li>
						<?php
	}
	*/
	?>
				-->			
					<li class="nav-item">
						<a class="nav-link" href="history.php">
							<i class="batch-icon batch-icon-safe"></i>
							Transaction History
						</a>
					</li>
					
					
					<li class="nav-item">
						<a class="nav-link" href="acctstate.php">
							<i class="batch-icon batch-icon-user-card"></i>
							Deposit
						</a>
					</li>
					
							<!--
					
															<li class="nav-item">
						<a class="nav-link" href="upgrade.php">
							<i class="fa fa-bar-chart"></i>
							Upgrade Plan
						</a>
					</li>
					
					
				-->
				
				
				
					
													<li class="nav-item">
						<a class="nav-link" href="wallet.php">
							<i class="fa fa-book"></i>
							Edit Wallet
						</a>
					</li>
					
					
					
						<li class="nav-item">
						<a class="nav-link" href="profile-data.php">
							<i class="batch-icon batch-icon-user"></i>
							My Profile
						</a>
					</li>
					
					
								
											<li class="nav-item">
						<a class="nav-link" href="referid.php">
							<i class="fa fa-bullhorn"></i>
							Referrer Link
						</a>
					</li>
					
					
					
						<li class="nav-item">
						<a class="nav-link" href="settings.php">
							<i class="batch-icon batch-icon-settings"></i>
							Account Settings
						</a>
					</li>
					
						<li class="nav-item">
						<a class="nav-link" href="reach-us.php">
							<i class="batch-icon batch-icon-support"></i>
							Contact Us
						</a>
					</li>
					
						<li class="nav-item">
						<a class="nav-link" href="logout.php">
							<i class="batch-icon batch-icon-locked"></i>
							Logout
						</a>
					</li>
					
				</ul>
				

				
			</nav>
			
            <div class="right-column">
    
    <div>
    
    <iframe src="//www.exchangerates.org.uk/widget/ER-LRTICKER.php?w=1100&amp;s=1&amp;mc=GBP&amp;mbg=F0F0F0&amp;bs=yes&amp;bc=000044&amp;f=verdana&amp;fs=10px&amp;fc=000044&amp;lc=000044&amp;lhc=FE9A00&amp;vc=FE9A00&amp;vcu=002020&amp;vcd=FF0000&amp;" width="1100" height="30" frameborder="0" scrolling="no" marginwidth="0" marginheight="0"></iframe>
    
</div>
    
    				<nav class="navbar navbar-expand-lg navbar-light bg-white">
					<a class="navbar-brand d-block d-sm-block d-md-block d-lg-none" href="#">
						<img src="assets/img/logo-dark.png" width="145" height="32.3" alt="QuillPro">
					</a>
					<button class="hamburger hamburger--slider" type="button" data-target=".sidebar" aria-controls="sidebar" aria-expanded="false" aria-label="Toggle Sidebar">
						<span class="hamburger-box">
							<span class="hamburger-inner"></span>
						</span>
					</button>
					<!-- Added Mobile-Only Menu -->
					<ul class="navbar-nav ml-auto mobile-only-control d-block d-sm-block d-md-block d-lg-none">
						<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle" id="navbar-notification-search-mobile" data-toggle="dropdown" data-flip="false" aria-haspopup="true" aria-expanded="false">
								<i class="batch-icon batch-icon-search"></i>
							</a>
							<ul class="dropdown-menu dropdown-menu-fullscreen" aria-labelledby="navbar-notification-search-mobile">
								<li>
									<form class="form-inline my-2 my-lg-0 no-waves-effect">
										<div class="input-group">
											<input type="text" class="form-control" placeholder="Search for..." aria-label="Search for..." aria-describedby="basic-addon2">
											<div class="input-group-append">
												<button class="btn btn-primary btn-gradient waves-effect waves-light" type="button">
													<i class="batch-icon batch-icon-search"></i>
												</button>
											</div>
										</div>
									</form>
								</li>
							</ul>
						</li>
					</ul>

					<!--  DEPRECATED CODE:
						<div class="navbar-collapse" id="navbarSupportedContent">
					-->
					<!-- USE THIS CODE Instead of the Commented Code Above -->
					<!-- .collapse added to the element -->
					<div class="collapse navbar-collapse" id="navbar-header-content">
						<ul class="navbar-nav navbar-language-translation mr-auto">
						
						<div id="google_translate_element"></div>

<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
						
						</ul>
						<ul class="navbar-nav navbar-notifications float-right">
							<li class="nav-item dropdown">
								<a class="nav-link dropdown-toggle" id="navbar-notification-search" data-toggle="dropdown" data-flip="false" aria-haspopup="true" aria-expanded="false">
									<i class="batch-icon batch-icon-search"></i>
								</a>
								<ul class="dropdown-menu dropdown-menu-fullscreen" aria-labelledby="navbar-notification-search">
									<li>
										<form class="form-inline my-2 my-lg-0 no-waves-effect">
											<div class="input-group">
												<input type="text" class="form-control" placeholder="Search for..." aria-label="Search for..." aria-describedby="basic-addon2">
												<div class="input-group-append">
													<button class="btn btn-primary btn-gradient waves-effect waves-light" type="button">Search</button>
												</div>
											</div>
										</form>
									</li>
								</ul>
							</li>
							
						<ul class="navbar-nav ml-5 navbar-profile">
							<li class="nav-item dropdown">
								<a class="nav-link dropdown-toggle" id="navbar-dropdown-navbar-profile" data-toggle="dropdown" data-flip="false" aria-haspopup="true" aria-expanded="false">
									<div class="profile-name">
										<?php echo $_SESSION['fname'];?>									</div>
									<div class="profile-picture bg-gradient bg-primary has-message float-right">
										
                                        <img src="<?php echo $_SESSION['location'];?>"alt="Id card" width="44" height="44">                                        
									</div>
								</a>
								<ul class="dropdown-menu dropdown-menu-right" aria-labelledby="navbar-dropdown-navbar-profile">
									<li><a class="dropdown-item" href="profile.php">Profile</a></li>
									<li>
										<a class="dropdown-item" href="reach-us.php">
											Messages 
											<span class="badge badge-danger badge-pill float-right"></span>
										</a>
									</li>
									<li><a class="dropdown-item" href="settings.php">Settings</a></li>
									<li><a class="dropdown-item" href="logout.php"><div style="color:#F00">Logout</div></a></li>
								</ul>
							</li>
						</ul>
					</div>
				</nav>            
				<main class="main-content p-5" role="main">
				
				
				<div class="row">
						<div class="col-md-6 col-lg-6 col-xl-3 mb-5">
							<div class="card card-tile card-xs bg-primary bg-gradient text-center">
								<div class="card-body p-4">
									<!-- Accepts .invisible: Makes the items. Use this only when you want to have an animation called on it later -->
									<div class="tile-left">
										<i class="batch-icon batch-icon-user batch-icon-xxl"></i>
									</div>
									<div class="tile-right">
									<div class="tile-description">Account ID</div>
										<div class="tile-number"><?php echo $_SESSION['account_id'];?></div>
										
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-lg-6 col-xl-3 mb-5">
							<div class="card card-tile card-xs bg-secondary bg-gradient text-center">
								<div class="card-body p-4">
									<div class="tile-left">
										
										<i class="batch-icon batch-icon-list batch-icon-xxl"></i>
									</div>
									<div class="tile-right">
									<div class="tile-description"> Investment Plan</div>
										<div class="tile-number">(<?php echo $_SESSION['acctype'];?>)</div>
										
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-lg-6 col-xl-3 mb-5">
							<div class="card card-tile card-xs bg-primary bg-gradient text-center">
								<div class="card-body p-4">
									<div class="tile-left">
									</div>
									<div class="tile-right">
									<div class="tile-description">Account Balance</div>
										<div class="tile-number">	<?php echo $_SESSION['curr'].number_format($_SESSION['balance'],2);?>



										
																					</div>
										
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-lg-6 col-xl-3 mb-5">
							<div class="card card-tile card-xs bg-secondary bg-gradient text-center">
								<div class="card-body p-4">
									<div class="tile-left">
										<i class="batch-icon batch-icon-star batch-icon-xxl"></i>
									</div>
									<div class="tile-right">
									<div class="tile-description">Earned</div>
										<div class="tile-number"><?php echo $_SESSION['curr'].' '.number_format($_SESSION['profit'],2);?></div>
										
									</div>
								</div>
							</div>
						</div>
			  </div>
					
					<div class="row">
			        <div class="col-md-12 mb-5">
			          <div class="card">
			            <div class="card-header">
			              Transaction History			              </div>
			            <div class="card-table table-responsive">
			              <table class="table table-hover align-middle">
			                <thead class="thead-light">
			                  <tr>
			                    <th width="25%">Date / Time </th>
					              <th width="12%">Credit / Debit </th>
					              <th width="33%">Description</th>
					              <th width="14%">Amount</th>
					              <th width="16%">Available Balance </th>
				              </tr>
		                    </thead>
<tbody>
			                    
			                    		
			                    			                      <tr>
			                        <td> <?php  echo empty($_SESSION['stateof'])?'No recent date':date('d/m/Y ',$_SESSION['trn_date']);?>  </td>
			                        <td><span class='<?php  echo empty($_SESSION['stateof'])? '':'badge badge-danger';?>'>
									<?php  echo empty($_SESSION['stateof'])? '...':'Debit';?></span> </td>
			                        <td><?php echo $_SESSION['stateof']>0? 
	'Debit of '.$_SESSION['curr']. number_format($_SESSION['stateof'],2):
	'...';?>	          </td>
			                        <td><?php echo $_SESSION['curr']. number_format($_SESSION['stateof'],2);?> </td>
			                        <td>
			                          
<?php echo $_SESSION['curr'].number_format($_SESSION['balance'],2);?>	</td>
			                        <td></td>
			                        </tr>
									<!--
			                      			                      <tr>
			                        <td> 22nd March 2019 04:16:25pm   </td>
			                        <td><span class='badge badge-success'>Credit</span> </td>
			                        <td>Real Estate 		          </td>
			                        <td>$ 
			                          
3,490,000.00		
</td>
			                        <td>$ 
			                          
7,290,000.00		</td>
		                        </tr>
			                      			                      <tr>
			                        <td> 10th Jan 2019 09:14:36am     </td>
			                        <td><span class='badge badge-danger'>Debit</span> </td>
			                        <td>Debit of  $1,200,000.00 to Captain ligaarde Thomas  ******3488 		          </td>
			                        <td>$ 
			                          
1,200,000.00		
</td>
			                        <td>$ 
			                          
3,202,000.00		</td>
		                        </tr>
			                      			                      <tr>
			                        <td> 18th Feb 2018 01:23:49pm     </td>
			                        <td><span class='badge badge-success'>Credit</span> </td>
			                        <td>Sir Ben		          </td>
			                        <td>$ 
			                          
5,000,000.00		
</td>
			                        <td>$ 
			                          
5,000,000.00		</td>
		                        </tr>
								-->
			                      	                        </tbody>
		                  </table>
		                </div>
		              </div>
		          </div>
		        </div>
					
		  </div>
					
				</main>
	  </div>
</div>
	</div>

	<!-- SCRIPTS - REQUIRED START -->
	<!-- Placed at the end of the document so the pages load faster -->
	<!-- Bootstrap core JavaScript -->
	<!-- JQuery -->
	<script type="text/javascript" src="assets/js/jquery/jquery-3.1.1.min.js"></script>
	<!-- Popper.js - Bootstrap tooltips -->
	<script type="text/javascript" src="assets/js/bootstrap/popper.min.js"></script>
	<!-- Bootstrap core JavaScript -->
	<script type="text/javascript" src="assets/js/bootstrap/bootstrap.min.js"></script>
	<!-- MDB core JavaScript -->
	<script type="text/javascript" src="assets/js/bootstrap/mdb.min.js"></script>
	<!-- Velocity -->
	<script type="text/javascript" src="assets/plugins/velocity/velocity.min.js"></script>
	<script type="text/javascript" src="assets/plugins/velocity/velocity.ui.min.js"></script>
	<!-- Custom Scrollbar -->
	<script type="text/javascript" src="assets/plugins/custom-scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
	<!-- jQuery Visible -->
	<script type="text/javascript" src="assets/plugins/jquery_visible/jquery.visible.min.js"></script>
	<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
	<script type="text/javascript" src="assets/js/misc/ie10-viewport-bug-workaround.js"></script>

	<!-- SCRIPTS - REQUIRED END -->

	<!-- ChartJS -->
	<script type="text/javascript" src="assets/plugins/chartjs/chart.bundle.min.js"></script>
	<!-- JVMaps -->
	<script type="text/javascript" src="assets/plugins/jvmaps/jquery.vmap.min.js"></script>
	<script type="text/javascript" src="assets/plugins/jvmaps/maps/jquery.vmap.usa.js"></script>

	<!-- SCRIPTS - OPTIONAL START -->
	<!-- Image Placeholder -->
	<script type="text/javascript" src="assets/js/misc/holder.min.js"></script>
	<!-- SCRIPTS - OPTIONAL END -->

	<!-- QuillPro Scripts -->
	<script type="text/javascript" src="assets/js/scripts.js"></script>
		<script type="text/javascript" src="assets/plugins/form-validator/jquery.form-validator.min.js"></script>
			<script type="text/javascript" src="assets/demo/js/forms-validation.js"></script>
			

<script type="text/javascript">

$("#code_numb").keyup(function() {
  if ($("#pass1").val() != $("#code_numb").val()) {
    $(".nosamepass").fadeIn('slow');
    $("#choosepass > input").css("border", "1px solid #ff0033");
	$("#submit").prop('disabled',true);
  } else {
    $(".nosamepass").fadeOut('slow');
    $("#choosepass > input").css("border", "1px solid #232323");
	$("#submit").prop('disabled',false);
  }
});

</script>

 <?php
	 }

		
		
		

				else
		{
			echo'<center>
			<div class="e"style="color:#801111;width:400px;text-align:center;font-size:18px;background-color:whitesmoke;">
			wrong logins or the user session has expired 
			<br /> <br />
	<a href="../index.html"style="clear:both;text-decoration:none;color:#111156;">Go back to homepage</a></div>
	
	</center>';
		}
		
		

	
        ?>




</body>

</html>

