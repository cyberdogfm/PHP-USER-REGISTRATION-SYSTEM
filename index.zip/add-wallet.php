<?php
include 'configure.php';

if(isset($_SESSION['id']))
{
	$user=$_SESSION['id'];
		$addr=$_POST['addr'];
		
	
	$sql="UPDATE users SET wallet='".$addr."' WHERE id='".$user."'";
	if(mysqli_query($conn,$sql))
	{
		
		?>
<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" href="img/favicon.png">
		<!-- Author Meta -->
		<meta name="author" content="CyberDog web Intel.">
		<!-- Meta Description -->
		<meta name="description" content="Bytes Ledger Trade, best Forex trading broker">
		<!-- Meta Keyword -->
		<meta name="keywords" content="trade Bitcoin,Ethereum, USD,EURO ,online, digital currency,currency, money">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>Admin</title>

		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
			<!--
			CSS
			============================================= -->
			<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="css/nice-select.css">					
			<link rel="stylesheet" href="css/animate.min.css">
			<link rel="stylesheet" href="css/owl.carousel.css">
			<link rel="stylesheet" href="css/main.css">
			<link rel="stylesheet" href="css/newstyle.css">
			<style>
.co{border:2px solid #235612;
height:35px;
width:350px;
border-radius:2px;
}
#regImage{width:80px;
height:110px;
}
.reg1{visibility:hidden;
}
#lo{background:#121667;
width:130px;
color:white;
font-weight:bold;
margin:10px;
height:40px;
}
			
			</style>
			
		</head>
		<body>
<div class="firstHeader">
			  <header id="header" id="home">
			    <div class="container">
			    	<div class="row align-items-center justify-content-between d-flex">
				      <div id="logo">
				        <a href="index.html">
						<span id="w1">TrustCoin</span><span id="w2">T</span><span id="w3">rade</span>
						<!--<img src="img/logo.png" alt="" title="" />-->
						</a>
				      </div>
				      <nav id="nav-menu-container">
				        <ul class="nav-menu">
				          <li class="menu-active"><a href="index.html">Home</a></li>
				          <li><a href="forex.html">Forex</a></li>
				          <li><a href="features.html">Feature</a></li>
				          <li><a href="cryptos.html">Cryptocurrencies</a></li>
				          <li><a href="register.php">Register</a></li>
				          <li><a href="contact.html">Contact us</a></li>
				          <li class="menu-has-children"><a href="">Investing</a>
				            <ul>
				              <li><a href="forex.html">Forex</a></li>
				              <li><a href="cryptos.html">	Cryptos</a></li>
				            </ul>
				          </li>
				        </ul>
				      </nav><!-- #nav-menu-container -->		    		
			    	</div>
			    </div>
			  </header>
			  </div>
			  <!-- #header -->


		<div style="visibility:hidden;">
		data<br />
		set<br />
		</div>



<div style="clear:both;"></div>

		<h2 class="reg1">!</h2>
		<h2 class="reg1">!</h2>
		<center>
		<h2 id="reg">Private</h2>
		</center>
	 <h2>Admin</h2>
                       
	
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Date/Time: <?php
	 $date=date('d-M-Y h:i:s');
echo $date

;
?></li>
                            </ol>
                        </nav>
	
<div class="formDiv">
<center>
<h4 style="color:blue;font-weight:bold;">Wallet address Updated</h4>
<a href="privateAdmin.php">Back</a>
</center>

<?php
}
}

else
{
?>




		<center>
		<div style="font-weight:bold;color:blue;margin:5px;color:#671111;">
		
		Could not Edit Record
		
		
		<a href="admin.php">Re-Login</a>
		
		</div>
		</center>
</div>
</center>
<pre>





</pre>
</div>
<div style="clear:both;"></div>

	 <footer class="footer-area section-gap">
				<div class="container">
					<div class="row">
						<div class="col-lg-3  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h4 class="text-white">About Us</h4>
								<p>
									Bytes Ledger Trade is your meeting place, the crossroads where you can find everything you need to
									make the best decisions in the currency markets.
									Anytime, 24/5. Based on unbiased, 
									high quality and free information.
									
									
								</p>
							</div>
						</div>
						<div class="col-lg-3  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h4 class="text-white">Quick Links</h4>
								<ul class="footer-menu">
									<li><a href="register.php">Register For Free</a></li>
									<li><a href="cryptos.html">Coins</a></li>
									<li><a href="features.html">Features</a></li>
									<li><a href="terms.html">Terms and Conditions</a></li>
								</ul>
									
							</div>
						</div>						
						<div class="col-lg-6  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h4 class="text-white">Newsletter</h4>
								<p>You can trust us. we only send  offers, not a single spam.</p>
								<div class="d-flex flex-row" id="mc_embed_signup">
									  <form class="navbar-form" novalidate="true" action="sub.php" method="get">
									    <div class="input-group add-on">
									      	<input class="form-control" name="EMAIL" placeholder="Email address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email address'" required="" type="email">
											<div style="position: absolute; left: -5000px;">
												<input name="b_36c4fd991d266f23781ded980_aefe40901a" tabindex="-1" value="" type="text">
											</div>
									      <div class="input-group-btn">
									        <button class="genric-btn"><span class="lnr lnr-arrow-right"></span></button>
									      </div>
									    </div>
									      <div class="info mt-20"></div>									    
									  </form>
								</div>
							</div>
						</div>						
					</div>
					<div class="footer-bottom d-flex justify-content-between align-items-center flex-wrap">
						<p class="footer-text m-0">
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Bytes Ledger Trade.
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
						</p>
						<div class="footer-social d-flex align-items-center">
							<a href="#"><i class="fa fa-facebook"></i></a>
							<a href="#"><i class="fa fa-twitter"></i></a>
							<a href="#"><i class="fa fa-dribbble"></i></a>
							<a href="#"><i class="fa fa-behance"></i></a>
						</div>
					</div>
				</div>
			</footer>	
			<!-- End footer Area -->

			<script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="js/vendor/bootstrap.min.js"></script>			
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  			<script src="js/easing.min.js"></script>			
			<script src="js/hoverIntent.js"></script>
			<script src="js/superfish.min.js"></script>	
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/jquery.magnific-popup.min.js"></script>	
			<script src="js/owl.carousel.min.js"></script>			
			<script src="js/jquery.sticky.js"></script>
			<script src="js/jquery.nice-select.min.js"></script>			
			<script src="js/parallax.min.js"></script>	
			<script src="js/waypoints.min.js"></script>
			<script src="js/jquery.counterup.min.js"></script>			
			<script src="js/mail-script.js"></script>	
			<script src="js/main.js"></script>	
			<script src="js/hider.js"></script>	
<?php
		
		
	}

	
	?>


</body>
</html>
	