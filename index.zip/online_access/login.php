<?php
$errr=$err2='';
if(isset($_GET['error']))
{
$errr="You entered a wrong character";
	
}
elseif(isset($_GET['inva']))
{
$err2="Your Email or Password is incorrect";
}	
?>


<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from goldentrustcoin.com/online_access/login.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 15 Apr 2021 03:39:13 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
<!--   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp"
    crossorigin="anonymous"> -->
    <script src="../../kit.fontawesome.com/8333780d97.js" crossorigin="anonymous"></script>
 <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous"> -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <title>Login Page</title>
</head>

<body style="background-color: #1B334D; overflow-x:hidden;">
  
  <section>
    <div class="container py-3">
    <div class="row">
      <div class="col-md-6 mx-auto my-5">
            <div class="card border-success text">
          <div class="card-header text-white text-center" style="background-color: #F4A03B;">
            <div class="card-text">
              <i class="fas fa-user-circle fa-3x"></i><h4>Account Login</h4>
            </div>
          </div>
		  <center>
		  <h5 style="color:red;background:whitesmoke;width:400px;font-size:19px;"><?php echo $errr;
	echo $err2;?></h5>
		  </center>
          <div class="card-body py-5 ">
                    <p class="bg-warning text-dark p-2"></p>
                    <form action="secure-profile.php" method="POST">
                      <div class="form-group">
                        <label for="username">Email/Account ID</label>
                        <input type="text" name="username" class="form-control" required>
                      </div>
                      <div class="form-group">
                        <label for="username">Password</label>
                        <input type="password" name="password" class="form-control" required>
                        <div class="form-text text-right"><a href="forgot_password.html">Forgot Password</a></div>
                      </div>
                      <input type="submit" value="LOGIN NOW" name="submit" class="btn btn-primary btn-block btn-lg">
                    </form>
           
          </div>
          <div class="card-footer">
            <div class="row">
              <div class="col-lg-8">
                <h5>Not a Member Yet?</h5>
              </div>
              <div class="col-lg-4">
                <a href="../sign-up.html" class="btn btn-outline-warning text-dark">Sign Up</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </section>

  <footer>
    <div class="row">
      <div class="col-md-12 text-dark text-center py-2" style="background-color: #F4A03B;">
        <p class="lead">Bytes Ledger Trade  <span id="year"></span></p>
      </div>
    </div>
  </footer>

<!-- This is an Old JQuery Snippet but it works well on Nav Drop down -->
<script src="../../code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
    crossorigin="anonymous"></script>
 <!-- This below Jquery snippet commented is the latest JQuery but it happens not to work well with my Nav Drop Down  -->
<!--  <script src="http://code.jquery.com/jquery-3.5.0.min.js" integrity="sha256-xNzN2a4ltkB44Mc/Jz3pT4iU1cmeR0FkXs4pru/JxaQ=" crossorigin="anonymous"></script> -->

<script src="../../cdn.jsdelivr.net/npm/popper.js%401.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="../../stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

<script>
	// Get the current year for the copyright
  $('#year').text(new Date().getFullYear());
</script>


<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/60835a195eb20e09cf360ed3/xxxfrtgs';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->	 
      
      
      
      

</body>


<!-- Mirrored from goldentrustcoin.com/online_access/login.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 15 Apr 2021 03:39:20 GMT -->
</html>