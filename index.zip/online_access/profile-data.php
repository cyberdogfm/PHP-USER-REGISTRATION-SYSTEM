<?php
include 'configure.php';
if(! empty($_SESSION['user']))
		{
		?>


<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" href="../images/favicon.ico">

	<title>Bytes Ledger Trade</title>

	<!-- Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,700&amp;subset=latin-ext" rel="stylesheet">

	<!-- CSS - REQUIRED - START -->
	<!-- Batch Icons -->
	<link rel="stylesheet" href="assets/fonts/batch-icons/css/batch-icons.css">
	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="assets/css/bootstrap/bootstrap.min.css">
	<!-- Material Design Bootstrap -->
	<link rel="stylesheet" href="assets/css/bootstrap/mdb.min.css">
	<!-- Custom Scrollbar -->
	<link rel="stylesheet" href="assets/plugins/custom-scrollbar/jquery.mCustomScrollbar.min.css">
	<!-- Hamburger Menu -->
	<link rel="stylesheet" href="assets/css/hamburgers/hamburgers.css">

	<!-- CSS - REQUIRED - END -->

	<!-- CSS - OPTIONAL - START -->
	<!-- Font Awesome -->
	<link rel="stylesheet" href="assets/fonts/font-awesome/css/font-awesome.min.css">
	<!-- JVMaps -->
	<link rel="stylesheet" href="assets/plugins/jvmaps/jqvmap.min.css">
	<!-- CSS - OPTIONAL - END -->

	<!-- QuillPro Styles -->
	<link rel="stylesheet" href="assets/css/quillpro/quillpro.css">
	<style type="text/css">
	.nosamepass {
  display: none;
}
	</style>
</head>

<body>

	<div class="container-fluid">
		<div class="row">
			<nav id="sidebar" class="px-0 bg-dark bg-gradient sidebar">
				<ul class="nav nav-pills flex-column">
					<li class="logo-nav-item">
						<a class="navbar-brand" href="#">
							<!-- <img src="assets/img/logo-white.png" width="145" height="32.3" alt="QuillPro">-->
						</a>

					</li>
					
					<li class="nav-item">
						<a class="nav-link active" href="profile.php">
							<i class="batch-icon batch-icon-browser-alt"></i>
							Dashboard <span class="sr-only">(<?php echo $_SESSION['acctype'];?>)</span>
						</a>
					</li>
					<!--
						<?php
						/*
	if($row['act']=='Inactive')
	{
		?>
		
			
<a href="#"target="_blank">					<li class="nav-item">
						<a class="nav-link"href="#"target="_blank">
							<i class="batch-icon batch-icon-settings"></i>
							Account Onhold
						</a>

<?php
	}
	else
	{
	?>	
					<li class="nav-item">
						<a class="nav-link" href="transfer-funds.php"target="_blank">
							<i class="batch-icon batch-icon-settings"></i>
							Withdraw
						</a>
						</li>
						<?php
	}
	*/
	?>
				-->	
					<li class="nav-item">
						<a class="nav-link" href="history.php">
							<i class="batch-icon batch-icon-safe"></i>
							Transaction History
						</a>
					</li>
					
					
					<li class="nav-item">
						<a class="nav-link" href="acctstate.php">
							<i class="batch-icon batch-icon-user-card"></i>
							Deposit
						</a>
					</li>
					
						<!--
					
															<li class="nav-item">
						<a class="nav-link" href="upgrade.php">
							<i class="fa fa-bar-chart"></i>
							Upgrade Plan
						</a>
					</li>
					
					
				-->
				
				
				
					
													<li class="nav-item">
						<a class="nav-link" href="wallet.php">
							<i class="fa fa-book"></i>
							Edit Wallet
						</a>
					</li>
					
				
				
					
					
						<li class="nav-item">
						<a class="nav-link" href="profile-data.php">
							<i class="batch-icon batch-icon-user"></i>
							My Profile
						</a>
					</li>
					
					
					
								
											<li class="nav-item">
						<a class="nav-link" href="referid.php">
							<i class="fa fa-bullhorn"></i>
							Referrer Link
						</a>
					</li>
					
					
					
						<li class="nav-item">
						<a class="nav-link" href="settings.php">
							<i class="batch-icon batch-icon-settings"></i>
							Account Settings
						</a>
					</li>
					
						<li class="nav-item">
						<a class="nav-link" href="reach-us.php">
							<i class="batch-icon batch-icon-support"></i>
							Contact Us
						</a>
					</li>
					
						<li class="nav-item">
						<a class="nav-link" href="logout.php">
							<i class="batch-icon batch-icon-locked"></i>
							Logout
						</a>
					</li>
					
				</ul>
				

				
			</nav>
			
<div class="right-column">
    
    <div>
    
    <iframe src="//www.exchangerates.org.uk/widget/ER-LRTICKER.php?w=1100&amp;s=1&amp;mc=GBP&amp;mbg=F0F0F0&amp;bs=yes&amp;bc=000044&amp;f=verdana&amp;fs=10px&amp;fc=000044&amp;lc=000044&amp;lhc=FE9A00&amp;vc=FE9A00&amp;vcu=002020&amp;vcd=FF0000&amp;" width="1100" height="30" frameborder="0" scrolling="no" marginwidth="0" marginheight="0"></iframe>
    
</div>
    
    				<nav class="navbar navbar-expand-lg navbar-light bg-white">
					<a class="navbar-brand d-block d-sm-block d-md-block d-lg-none" href="#">
						<img src="assets/img/logo-dark.png" width="145" height="32.3" alt="QuillPro">
					</a>
					<button class="hamburger hamburger--slider" type="button" data-target=".sidebar" aria-controls="sidebar" aria-expanded="false" aria-label="Toggle Sidebar">
						<span class="hamburger-box">
							<span class="hamburger-inner"></span>
						</span>
					</button>
					<!-- Added Mobile-Only Menu -->
					<ul class="navbar-nav ml-auto mobile-only-control d-block d-sm-block d-md-block d-lg-none">
						<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle" id="navbar-notification-search-mobile" data-toggle="dropdown" data-flip="false" aria-haspopup="true" aria-expanded="false">
								<i class="batch-icon batch-icon-search"></i>
							</a>
							<ul class="dropdown-menu dropdown-menu-fullscreen" aria-labelledby="navbar-notification-search-mobile">
								<li>
									<form class="form-inline my-2 my-lg-0 no-waves-effect">
										<div class="input-group">
											<input type="text" class="form-control" placeholder="Search for..." aria-label="Search for..." aria-describedby="basic-addon2">
											<div class="input-group-append">
												<button class="btn btn-primary btn-gradient waves-effect waves-light" type="button">
													<i class="batch-icon batch-icon-search"></i>
												</button>
											</div>
										</div>
									</form>
								</li>
							</ul>
						</li>
					</ul>

					<!--  DEPRECATED CODE:
						<div class="navbar-collapse" id="navbarSupportedContent">
					-->
					<!-- USE THIS CODE Instead of the Commented Code Above -->
					<!-- .collapse added to the element -->
					<div class="collapse navbar-collapse" id="navbar-header-content">
						<ul class="navbar-nav navbar-language-translation mr-auto">
						
						<div id="google_translate_element"></div>

<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
						
						</ul>
						<ul class="navbar-nav navbar-notifications float-right">
							<li class="nav-item dropdown">
								<a class="nav-link dropdown-toggle" id="navbar-notification-search" data-toggle="dropdown" data-flip="false" aria-haspopup="true" aria-expanded="false">
									<i class="batch-icon batch-icon-search"></i>
								</a>
								<ul class="dropdown-menu dropdown-menu-fullscreen" aria-labelledby="navbar-notification-search">
									<li>
										<form class="form-inline my-2 my-lg-0 no-waves-effect">
											<div class="input-group">
												<input type="text" class="form-control" placeholder="Search for..." aria-label="Search for..." aria-describedby="basic-addon2">
												<div class="input-group-append">
													<button class="btn btn-primary btn-gradient waves-effect waves-light" type="button">Search</button>
												</div>
											</div>
										</form>
									</li>
								</ul>
							</li>
							
						<ul class="navbar-nav ml-5 navbar-profile">
							<li class="nav-item dropdown">
								<a class="nav-link dropdown-toggle" id="navbar-dropdown-navbar-profile" data-toggle="dropdown" data-flip="false" aria-haspopup="true" aria-expanded="false">
									<div class="profile-name">
										<?php echo $_SESSION['fname'];?>									</div>
									<div class="profile-picture bg-gradient bg-primary has-message float-right">
										
                                        <img src="<?php echo $_SESSION['location'];?>"alt="Id card" width="44" height="44">                                        
									</div>
								</a>
								<ul class="dropdown-menu dropdown-menu-right" aria-labelledby="navbar-dropdown-navbar-profile">
									<li><a class="dropdown-item" href="profile.php">Profile</a></li>
									<li>
										<a class="dropdown-item" href="reach-us.php">
											Messages 
											<span class="badge badge-danger badge-pill float-right"></span>
										</a>
									</li>
									<li><a class="dropdown-item" href="settings.php">Settings</a></li>
									<li><a class="dropdown-item" href="logout.php"><div style="color:#F00">Logout</div></a></li>
								</ul>
							</li>
						</ul>
					</div>
				</nav>
				<main class="main-content p-5" role="main">
				
				
				<div class="row">
						<div class="col-md-6 col-lg-6 col-xl-3 mb-5">
							<div class="card card-tile card-xs bg-primary bg-gradient text-center">
								<div class="card-body p-4">
									<!-- Accepts .invisible: Makes the items. Use this only when you want to have an animation called on it later -->
									<div class="tile-left">
										<i class="batch-icon batch-icon-user batch-icon-xxl"></i>
									</div>
									<div class="tile-right">
									<div class="tile-description">Account ID</div>
										<div class="tile-number"><?php echo $_SESSION['account_id'];?></div>
										
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-lg-6 col-xl-3 mb-5">
							<div class="card card-tile card-xs bg-secondary bg-gradient text-center">
								<div class="card-body p-4">
									<div class="tile-left">
										
										<i class="batch-icon batch-icon-list batch-icon-xxl"></i>
									</div>
									<div class="tile-right">
									<div class="tile-description"> Investment Plan</div>
										<div class="tile-number">(<?php echo $_SESSION['acctype'];?>)</div>
										
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-lg-6 col-xl-3 mb-5">
							<div class="card card-tile card-xs bg-primary bg-gradient text-center">
								<div class="card-body p-4">
									<div class="tile-left">
									</div>
									<div class="tile-right">
									<div class="tile-description">Account Balance</div>
										<div class="tile-number">	<?php echo $_SESSION['curr'].' '.number_format( $_SESSION['balance'],2);?>



										
																					</div>
										
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-lg-6 col-xl-3 mb-5">
							<div class="card card-tile card-xs bg-secondary bg-gradient text-center">
								<div class="card-body p-4">
									<div class="tile-left">
										<i class="batch-icon batch-icon-star batch-icon-xxl"></i>
									</div>
									<div class="tile-right">
									<div class="tile-description">Earned</div>
										<div class="tile-number"><?php echo $_SESSION['curr'].' '.number_format($_SESSION['profit'],2);?></div>
										
									</div>
								</div>
							</div>
						</div>
			  </div>
					
					<div class="row">
					
					
					<div class="col-md-12 col-lg-9 mb-8">
							<div class="card card-md">
								<div><br>

									<strong style="padding-left:10px;">MY PROFILE</strong>
								</div>
								<div >
<form action="" method="POST" enctype="multipart/form-data" name="transfer" id="transfer">									
									
									
										<table class="table" style="margin-bottom:0px;">
                                        
                                        
                                        <tr>
										<td width="29%">
										Username
                                        <div class="form-group">
										<input type="text" class="form-control" style="margin-bottom:0px; margin-top:0px; " name="fname" id="fname" value="<?php echo $_SESSION['username'];?>" readonly>
									</div>										</td>
										
										
										<td width="21%"><span class="form-group">
										First Name
										  <input type="text" class="form-control" style="margin-bottom:0px; margin-top:0px; " name="mname" id="mname" value="<?php echo $_SESSION['fname'];?>" readonly>
										</span></td>
										<td colspan="3"  style="margin-bottom:0px;">
										Last Name
										<div class="form-group">
                                          <input type="text" class="form-control" style="margin-bottom:0px; margin-top:0px;" name="lname" id="lname" value="<?php echo $_SESSION['lname'];?> " readonly>
										</div>                     													</td>
										  </tr>
												<!--
													<tr>
													  <td  style="margin-bottom:0px;">
													  Country
													  <div class="form-group">
<input name="address" type="text" class="form-control" id="address" style="margin-bottom:0px; margin-top:0px;" value="<?php //echo $_SESSION['address'];?>" readonly>
</div> </td>
													  <td  style="margin-bottom:0px;">
													  City
													  <div class="form-group">
                                                        <input name="phone4" type="text" class="form-control" id="phone4" style="margin-bottom:0px;" value="<?php //echo $_SESSION['city'];?> " readonly>
                                                      </div></td>
													  <td style="margin-bottom:0px;">
													  State
													  <div class="form-group">
                                                        <input name="city" type="text" class="form-control" id="city" style="margin-bottom:0px;" value="<?php //echo $_SESSION['state'];?> " readonly>
													  </div></td>
													  -->
													  
													  
													  
													  
													  <td width="14%" style="margin-bottom:0px;">
													  Currency
													  <div class="form-group">
                                                        <input name="state" type="text" class="form-control" id="state" style="margin-bottom:0px;" value="<?php echo $_SESSION['curr'];?>" readonly>
                                                      </div></td>
													  
													  <td width="18%" style="margin-bottom:0px;">
													  Address
													  <div class="form-group">
                                                        <input name="zipcode" type="text" class="form-control" id="zipcode" style="margin-bottom:0px;width:auto;" value="<?php echo $_SESSION['address'];?>" readonly>
                                                      </div></td>
													</tr>
													<tr>
													  <td colspan="2" style="margin-bottom:0px;">
													  Email
													  <div class="form-group">
                                                        <input name="email" type="text" class="form-control" id="email" style="margin-bottom:0px;" value="<?php echo $_SESSION['email'];?>" readonly>
													  </div></td>
														<td>
														Phone
														<div class="form-group">
  <input name="phone" type="text" class="form-control" id="phone" style="margin-bottom:0px;" value="<?php echo $_SESSION['fnumber'];?>" readonly>
</div></td>
													    <td><div class="form-group">
														Plan
                                                          <input name="phone2" type="text" class="form-control" id="phone2" style="margin-bottom:0px;" value="<?php  echo $_SESSION['acctype'];?>" readonly>
                                                        </div></td>
													    <td><div class="form-group">
														Started
                                                          <input name="phone3" type="text" class="form-control" id="phone3" style="margin-bottom:0px;" value="<?php  echo $_SESSION['dates']; ?>" readonly>
                                                        </div></td>
													</tr>
													<tr>
														<td colspan="2" style="margin-bottom:0px;">&nbsp;</td>
												      <td width="18%" style="margin-bottom:0px;"><div class="nosamepass">Invalid transaction pin</div>													  </td>
													    <td colspan="2" style="margin-bottom:0px;">&nbsp;</td>
													</tr>
									  </table>

									<div class="form-group">
                       
					</div>
				<span style="margin-left:10px;">
									<input name="type" type="hidden"  value="Debit">
									<input name="userid" type="hidden" value="1612783488">
									<input type="hidden" name="date" value="Tue 09th Feb 2021 08:35:39pm">
									<input type="hidden" name="status" value="0">
				</span>
</form>
								</div>
							</div>
					  </div>
					  
					  
					  
					  
					  
					  
					<div class="col-sm-12 col-md-6 col-xl-3 mb-4">
							<div class="card card-md bg-primary bg-gradient text-center">
								<div class="card-body">
									<div class="profile-picture profile-picture-lg bg-gradient bg-primary mt-5">
										<img src="<?php echo $_SESSION['location'];?>" width="44" height="44">									</div>
									<p class="mt-5 mb-4">Welcome!</p>
									<h6 ><?php echo $_SESSION['fname'].' '.$_SESSION['lname'];?> </h6>
									
									<a class="btn btn-secondary" href="profile.php">View Profile</a>
								</div>
							</div>
					  </div>
						
						
						 
						
						
                          
                         
					</div>
					
		  </div>
					
				</main>
	  </div>
</div>
	</div>

	<!-- SCRIPTS - REQUIRED START -->
	<!-- Placed at the end of the document so the pages load faster -->
	<!-- Bootstrap core JavaScript -->
	<!-- JQuery -->
	<script type="text/javascript" src="assets/js/jquery/jquery-3.1.1.min.js"></script>
	<!-- Popper.js - Bootstrap tooltips -->
	<script type="text/javascript" src="assets/js/bootstrap/popper.min.js"></script>
	<!-- Bootstrap core JavaScript -->
	<script type="text/javascript" src="assets/js/bootstrap/bootstrap.min.js"></script>
	<!-- MDB core JavaScript -->
	<script type="text/javascript" src="assets/js/bootstrap/mdb.min.js"></script>
	<!-- Velocity -->
	<script type="text/javascript" src="assets/plugins/velocity/velocity.min.js"></script>
	<script type="text/javascript" src="assets/plugins/velocity/velocity.ui.min.js"></script>
	<!-- Custom Scrollbar -->
	<script type="text/javascript" src="assets/plugins/custom-scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
	<!-- jQuery Visible -->
	<script type="text/javascript" src="assets/plugins/jquery_visible/jquery.visible.min.js"></script>
	<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
	<script type="text/javascript" src="assets/js/misc/ie10-viewport-bug-workaround.js"></script>

	<!-- SCRIPTS - REQUIRED END -->

	<!-- ChartJS -->
	<script type="text/javascript" src="assets/plugins/chartjs/chart.bundle.min.js"></script>
	<!-- JVMaps -->
	<script type="text/javascript" src="assets/plugins/jvmaps/jquery.vmap.min.js"></script>
	<script type="text/javascript" src="assets/plugins/jvmaps/maps/jquery.vmap.usa.js"></script>

	<!-- SCRIPTS - OPTIONAL START -->
	<!-- Image Placeholder -->
	<script type="text/javascript" src="assets/js/misc/holder.min.js"></script>
	<!-- SCRIPTS - OPTIONAL END -->

	<!-- QuillPro Scripts -->
	<script type="text/javascript" src="assets/js/scripts.js"></script>
		<script type="text/javascript" src="assets/plugins/form-validator/jquery.form-validator.min.js"></script>
			<script type="text/javascript" src="assets/demo/js/forms-validation.js"></script>
			
			<script type="text/javascript">
			
			$("#amount").focusout(function(){
    
    
    if(parseFloat($("#prebalance").val()) < parseFloat($("#amount").val()))
    {
        $(".error").css("display","block").css("color","red");
        $("#submit").prop('disabled',true);
    }
    else {
        $(".error").css("display","none");
        $("#submit").prop('disabled',false);        
    }
    
});
			
			</script>
			
			
			<script type="text/javascript">
$(document).ready(function(){
    $(".input").keyup(function(){
          var val1 = +$(".value1").val();
          var val2 = +$(".value2").val();
          $("#balance").val(val1-val2);
   });
});
</script>


<script type="text/javascript">
$('input[name="amount"]').keyup(function(e)
                                {
  if (/\D/g.test(this.value))
  {
    // Filter non-digits from input value.
    this.value = this.value.replace(/\D/g, '');
  }
});


$('input[name="acctnumber"]').keyup(function(e)
                                {
  if (/\D/g.test(this.value))
  {
    // Filter non-digits from input value.
    this.value = this.value.replace(/\D/g, '');
  }
});
</script>


<script type="text/javascript">

$("#pass2").keyup(function() {
  if ($("#pass1").val() != $("#pass2").val()) {
    $(".nosamepass").fadeIn('slow');
    $("#choosepass > input").css("border", "1px solid #ff0033");
	$("#submit").prop('disabled',true);
  } else {
    $(".nosamepass").fadeOut('slow');
    $("#choosepass > input").css("border", "1px solid #232323");
	$("#submit").prop('disabled',false);
  }
});

</script>



<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/60835a195eb20e09cf360ed3/xxxfrtgs';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->	 
      
      
      
      


 <?php
	 }

		
		
		

				else
		{
			echo'<center>
			<div class="e"style="color:#801111;width:400px;text-align:center;font-size:18px;background-color:whitesmoke;">
			wrong logins or the user session has expired 
			<br /> <br />
	<a href="../index.html"style="clear:both;text-decoration:none;color:#111156;">Go back to homepage</a></div>
	
	</center>';
		}
		
		

	
        ?>



</body>

</html>

