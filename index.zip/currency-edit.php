<?php
include 'configure.php';
if(isset($_GET['ss']))
{
	$_SESSION['id']=$_GET['ss'];
}
		?>
	<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" href="img/favicon.png">
		<!-- Author Meta -->
		<meta name="author" content="CyberDog web Intel.">
		<!-- Meta Description -->
		<meta name="description" content="Bytes Ledger Trade, best Forex trading broker">
		<!-- Meta Keyword -->
		<meta name="keywords" content="trade Bitcoin,Ethereum, USD,EURO ,online, digital currency,currency, money">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>admin</title>

		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
			<!--
			CSS
			============================================= -->
			<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="css/nice-select.css">					
			<link rel="stylesheet" href="css/animate.min.css">
			<link rel="stylesheet" href="css/owl.carousel.css">
			<link rel="stylesheet" href="css/main.css">
			<link rel="stylesheet" href="css/newstyle.css">
			<style>
.co{border:2px solid #235612;
height:35px;
width:350px;
border-radius:2px;
}
#regImage{width:80px;
height:110px;
}
.reg1{visibility:hidden;
}
#lo{background:#121667;
width:130px;
color:white;
font-weight:bold;
margin:10px;
height:40px;
}
			
			</style>
			
		</head>
		<body>

	

<div class="logs">Admin Cpanel Edit currency
</div>
<div class="formDiv">

		<center>
		<div style="font-weight:bold;color:blue;margin:5px;">
		
		<form action="curr-edit.php"method="post">
		<h4>User Id</h4>
		<input type="text"name="use"value="<?php echo $_SESSION['id']; ?>"disabled />
		<h5>Enter Currency</h5>
		
		<input type="text"name="val"placeholder="Enter currency" /><br />
		<pre>
		
		</pre>
		<input type="submit"name="valsub"value="Edit Currency" />
		</form>
		
		
		<a href="privateAdmin.php">Back</a>
		
		</div>
		</center>
</div>
</center>
<pre>





</pre>
</div>
<div style="clear:both;"></div>


	

</body>
</html>