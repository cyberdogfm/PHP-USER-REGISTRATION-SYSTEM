CREATE TABLE `history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `usern` varchar(255) NOT NULL,
  `numone` varchar(255) NOT NULL,
  `numonedate` varchar(255) NOT NULL,
  `numonedesc` varchar(255) NOT NULL,
  `numonebalance` varchar(255) NOT NULL,
  `numonetype` varchar(255) NOT NULL,
  `numtwo` varchar(255) NOT NULL,
  `numtwodate` varchar(255) NOT NULL,
  `numtwodesc` varchar(255) NOT NULL,
  `numtwobalance` varchar(255) NOT NULL,
  `numtwotype` varchar(255) NOT NULL,
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1001;

