<?php
//We start sessions
session_start();

/******************************************************
------------------Required Configuration---------------
Please edit the following variables so the members area
can work correctly.
******************************************************/

	// this will avoid mysql_connect() deprecation error.
	error_reporting( ~E_DEPRECATED & ~E_NOTICE );
	// but I strongly suggest you to use PDO or MySQLi.
	
	define('DBHOST', 'localhost');
	define('DBUSER', 'u562826468_bt_user');
	define('DBPASS','ikhT56JJJG6hrr7nh');
	define('DBNAME', 'u562826468_bt_db');
	
	

	
	
	
	
	$conn = mysqli_connect(DBHOST,DBUSER,DBPASS,DBNAME);
	
	if ( !$conn ) {
		die("Connection failed : " . mysqli_connect_errno());
	}
	
	//if ( !$dbcon ) {
	//	die("Database Connection failed : " . mysql_error());
	//}

//We log to the DataBase
//mysql_connect('hote', 'username', 'password');
//mysql_select_db('database');

//Webmaster Email
$mail_webmaster = 'example@example.com';

//Top site root URL
$url_root = 'http://www.example.com/';

/******************************************************
-----------------Optional Configuration----------------
******************************************************/

//Home page file name
$url_home = 'index.php';

//Design Name
$design = 'default';
?>