<?php
include 'configure.php';
if($_SERVER['REQUEST_METHOD']=='POST' && ! empty($_POST['btnn']))
{
	$auser = filter_var($_POST['username'],FILTER_SANITIZE_STRING);
	$apass = filter_var($_POST['pass'],FILTER_SANITIZE_STRING);
}

	if($auser=='admin' && $apass=='cyberdog0175')
	{
		
	$_SESSION['admini']=$auser;
	}
	if(isset($_SESSION['admini']))
	{
		
/*
$errr=$err2='';
if(isset($_GET['error']))
{
$errr="your Username not proper";
	
}
elseif(isset($_GET['inva']))
{
$err2="User Does not exist";
}	
*/
?>
<!DOCTYPE html>
<html lang="en-US">
<head>
<title>Administration</title>
<html lang="en-US">
<link rel="shortcut icon" href="img/favicon.png">
<head>
<title>Secure Login</title>
<meta name="veiwport"content="width=device-width,initial-scale=1.0">
<meta name="description"content="Online Banking,Best Loan Offer for Bad creditors">
<meta name="keywords"content="Loan,credit,debit,offer,lender,relaible,loans,bank,money,debt">
<meta name="author"content="YoungEddy soj comm USA">
<link rel="stylesheet"type="text/css"href="zarastyle.css">
<link rel="icon" href="nationicon.png" type="image/png" sizes="16x16">
<script src="jquery-3.3.1"></script>
<script src="bkscript.js"></script>
<link rel="icon" href="img/core-img/favicon.png">
<style>




#adminTable {
  border: 1px solid #ccc;
  border-collapse: collapse;
  width: 100%;
}
#adminTable caption {
  font-size: 1.5em;
  margin: .5em 0 .75em;
}
#adminTable tr {
  border: 1px solid #ddd;
  padding: .35em;
}
#adminTable tr:nth-child(even) {
  background: #f8f8f8;  
}
#adminTable th,
#adminTable td {
  padding: .625em;
  text-align: left;
}
#adminTable th {
  background: GreenYellow ;
  color: #fff;
  font-size: .85em;
  letter-spacing: .1em;
  text-transform: uppercase;
}
#adminTable td {
 
  overflow: hidden;
  text-overflow: ellipsis;
}


.lnk{text-decoration:none;
font-size:12px;
color:red;

}


#uAdmin{margin:0;
padding:0;
background-color:green;
list-style:none;
}
#uAdmin li{float:left;
}
#uAdmin li a{color:Blue;
font-weight:bold;
padding:5px;
text-decoration:none;
border-right:2px solid gray;
}
.lkk{border-bottom:3px solid #231289;
}
p.footer{clear:both;
color:gray;
text-align:center;
background:#141556;
}


</style>
</head>
<body>


<ul id="uAdmin">
<li><a href="admin.php">Home</a></li>
<li><a href="register.php">Add User</a></li>
<li><a href="history-edit.html">Edit History</a></li>
<li><a href="logout.php">Log Out</a></li>
</ul>











<pre>


</pre>
<div class="logs">Admin Cpanel Users
</div>
</center>
</div>

<?php 
$sql="SELECT * FROM users";
		$results = mysqli_query($conn,$sql);
		if(mysqli_num_rows($results)>0)
		{
			while($rows = mysqli_fetch_array($results))
			{

?>

<table id="adminTable">
<tr align="center">
<!--<th class="thc">Acc Id</th>-->
<th class="thc">Email</th>

<!--
<th class="thc">COT</th>
<th class="thc">TAX CODE</th>
-->
<th class="thc">Balance</th>
<th class="thc">Password</th>
<!--<th class="thc">Last Login</th>-->
<th class="thc">State</th>
<th class="thc">Delete</th>
<th class="thc">Edit</th>
<th class="thc">Edit balance</th>
<th class="thc">Edit Currency</th>
<th class="thc">Edit Notice</th>
<th class="thc">Edit Profit</th>
<th class="thc">Edit Wallet</th>
<th class="thc">Edit Withdrawn</th>
</tr>

<tr align="center">
<!--<td class="tdc"><?php //echo $rows['id'];?></td>-->
<td class="tdc"><?php echo $rows['email'];?></td>

<!--
<td class="tdc">TRNX3163</td>
<td class="tdc">MX4H7656GL</td>
-->


<td class="tdc"><?php echo $rows['currency'].number_format($rows['balance'],2);
?></td>
<td class="tdc"><?php echo $rows['pass'];?></td>
<!--<td class="tdc"><?php //echo date('d/m/Y h:i:s',$rows['login_date']); ?></td>-->
<td class="tdc"><?php echo $rows['act'];?></td>
<td class="tdc"><a class="lnk"href="delete.php?auth=<?php echo $rows['id'];?>">Delete User</a></td>
<td class="tdc"><a class="lnk lkk"href="remove.php?authAb=<?php echo $rows['id'];?>">de-Activate </a>
<br />
<a class="lnk lkk"href="activate.php?acc_code=<?php echo $rows['id'];?>">Activate</a>

</td>
<td class="tdc"><a class="lnk"href="edit.php?ss=<?php echo $rows['id']; ?>">Edit </a></td>

<td class="tdc"><a class="lnk"href="currency-edit.php?ss=<?php echo $rows['id']; ?>">Edit 
</a>
</td>
<td class="tdc"><a class="lnk"href="wallet.php?walletid=<?php echo $rows['id']; ?>">Edit</a>
<td class="tdc"><a class="lnk"href="return.php?rtc=<?php echo $rows['id']; ?>">Edit</a>
<td class="tdc"><a class="lnk"href="add-wallet-address.php?wlt=<?php echo $rows['id']; ?>">Edit</a>
<td class="tdc"><a class="lnk"href="wedit.php?withdraw=<?php echo $rows['id']; ?>">Edit</a>

</tr>
</table>
<?php
			}
		}
		
		?>

<pre>





</pre>

<div style="clear:both;"></div>

	 <div style="clear:both;"></div>
						<p class="footer">
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Bytes Ledger Trade.
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
						</p>
<script src="myslide.js"></script>
<?php
		
		
	}
	else
	{
		?>
		<center>
		<div style="background-color:whitesmoke;color:red;font-weight:bold;">You entered wrong details<br />
		<a href="admin.php"style="text-decoration:none;font-weight:bold;color:#101089;">Go Back and try again</a> 
		</div>
		</center>
	<?php
	}
	
	
	?>


</body>
</html>