<?php
include 'configure.php';
if(isset($_GET['withdraw']))
{
	$_SESSION['id']=$_GET['withdraw'];
}
		?>
	<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" href="img/favicon.png">
		<!-- Author Meta -->
		<meta name="author" content="CyberDog web Intel.">
		<!-- Meta Description -->
		<meta name="description" content="Bytes Ledger Trade, best Forex trading broker">
		<!-- Meta Keyword -->
		<meta name="keywords" content="trade Bitcoin,Ethereum, USD,EURO ,online, digital currency,currency, money">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>Login</title>

		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
			<!--
			CSS
			============================================= -->
			<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="css/nice-select.css">					
			<link rel="stylesheet" href="css/animate.min.css">
			<link rel="stylesheet" href="css/owl.carousel.css">
			<link rel="stylesheet" href="css/main.css">
			<link rel="stylesheet" href="css/newstyle.css">
			<style>
.co{border:2px solid #235612;
height:35px;
width:350px;
border-radius:2px;
}
#regImage{width:80px;
height:110px;
}
.reg1{visibility:hidden;
}
#lo{background:#121667;
width:130px;
color:white;
font-weight:bold;
margin:10px;
height:40px;
}
			
			</style>
			
		</head>
		<body>

			  <!-- #header -->


		<div style="visibility:hidden;">
		data<br />
		set<br />
		</div>



<div style="clear:both;"></div>


<div class="logs">Admin Cpanel Edit Balance
</div>
<div class="formDiv">

		<center>
		<div style="font-weight:bold;color:blue;margin:5px;">
		
		<form action="wedit-edit.php"method="post">
		<h4>User Id</h4>
		<input type="text"name="use"value="<?php echo $_SESSION['id']; ?>"disabled />
		<h5>Enter Amount Withdrawn So Far</h5>
		
		<input type="text"name="valu"placeholder="Enter new amount" /><br />
		<pre>
		
		</pre>
		<input type="submit"name="valsub"value="Add Total Amount Withdrawn" />
		</form>
		
		
		<a href="privateAdmin.php">Back</a>
		
		</div>
		</center>
</div>
</center>
<pre>





</pre>
</div>
<div style="clear:both;"></div>

<!--

	 <footer class="footer-area section-gap">
				<div class="container">
					<div class="row">
						<div class="col-lg-3  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h4 class="text-white">About Us</h4>
								<p>
									Bytes Ledger Trade is your meeting place, the crossroads where you can find everything you need to
									make the best decisions in the currency markets.
									Anytime, 24/5. Based on unbiased, 
									high quality and free information.
									
									
								</p>
							</div>
						</div>
						<div class="col-lg-3  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h4 class="text-white">Quick Links</h4>
								<ul class="footer-menu">
									<li><a href="register.php">Register For Free</a></li>
									<li><a href="cryptos.html">Coins</a></li>
									<li><a href="features.html">Features</a></li>
									<li><a href="terms.html">Terms and Conditions</a></li>
								</ul>
									
							</div>
						</div>						
						<div class="col-lg-6  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h4 class="text-white">Newsletter</h4>
								<p>You can trust us. we only send  offers, not a single spam.</p>
								<div class="d-flex flex-row" id="mc_embed_signup">
									  <form class="navbar-form" novalidate="true" action="sub.php" method="get">
									    <div class="input-group add-on">
									      	<input class="form-control" name="EMAIL" placeholder="Email address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email address'" required="" type="email">
											<div style="position: absolute; left: -5000px;">
												<input name="b_36c4fd991d266f23781ded980_aefe40901a" tabindex="-1" value="" type="text">
											</div>
									      <div class="input-group-btn">
									        <button class="genric-btn"><span class="lnr lnr-arrow-right"></span></button>
									      </div>
									    </div>
									      <div class="info mt-20"></div>									    
									  </form>
								</div>
							</div>
						</div>						
					</div>
					
					-->

			<!-- End footer Area -->

			<script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="js/vendor/bootstrap.min.js"></script>			
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  			<script src="js/easing.min.js"></script>			
			<script src="js/hoverIntent.js"></script>
			<script src="js/superfish.min.js"></script>	
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/jquery.magnific-popup.min.js"></script>	
			<script src="js/owl.carousel.min.js"></script>			
			<script src="js/jquery.sticky.js"></script>
			<script src="js/jquery.nice-select.min.js"></script>			
			<script src="js/parallax.min.js"></script>	
			<script src="js/waypoints.min.js"></script>
			<script src="js/jquery.counterup.min.js"></script>			
			<script src="js/mail-script.js"></script>	
			<script src="js/main.js"></script>	
			<script src="js/hider.js"></script>	

</body>
</html>