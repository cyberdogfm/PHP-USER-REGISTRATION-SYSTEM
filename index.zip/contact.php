<?php
 include'configure.php';
	 if(isset($_POST['first_name'],$_POST['last_name'],$_POST['email'],$_POST['address'] ,$_POST['msg']))
	 {

	$full_name=$_POST['fname'];
	$email=$_POST['email'];
	$subject=$_POST['subject'];
	$phone=$_POST['phone'];
	
	$message=$_POST['message'];
	 }
	
	$vals ='Full Name: '.$full_name."<br />".'Email: '.$email."<br />".'Subject: '.$subject."<br />".'Phone: '.$phone."<br />". 'Message: '.$message;
	if(mail('youngsu721@gmail.com','Bytes Ledger Trade Mail',$vals))
	{
	/*
	$age=$_POST['age'];
	$gender=$_POST['gender'];
	
	$security=$_POST['security'];
	if($security=='cyberdog004484')
	{
		
		
	if (!isset($_FILES['userfile']['tmp_name']))
		{
	echo "";
	}
	$filetype=$_FILES['userfile']['type'];
	$allowed=array('image/jpeg','image/gif','image/png','image/jpg');
	if(! in_array($filetype,$allowed))
	{
		header("location:create.php?fileerror=$err");
		exit();
	}
	else{
	$file=$_FILES['userfile']['tmp_name'];
	$image= addslashes(file_get_contents($_FILES['userfile']['tmp_name']));
	$image_name= addslashes($_FILES['userfile']['name']);		
			move_uploaded_file($_FILES["userfile"]["tmp_name"],"photos/" . $_FILES["userfile"]["name"]);
			
			$location="photos/" . $_FILES["userfile"]["name"];
		
		
	
	if(mysqli_query($conn,'insert into users(email,fname,pass,dates,address,gender,promoCode,location) values ("'.$email.'","'.$accountName.'","'.$pass.'",'.$date.', "'.$address.'","'.$gender.'","'.$promoCode.'","'.$location.'")'))
					{
						
						*/
	?>


<!DOCTYPE html>
<html lang="en">
   
<!-- Mirrored from goldentrustcoin.com/contact-us.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 15 Apr 2021 03:40:02 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
      <!-- Basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- Mobile Metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- Site Metas -->
      
      <meta http-equiv="Content-Type" charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<meta name="description" content="Bytes Ledger Trade is one of the World&#39;s Leading Trading and Investment Broker. Start Trading CFD&#39;s, Commodities, Indices, Stocks and more with Bytes Ledger Trade&#39;s ÃƒÆ’Ã‚Â¢Ãƒâ€¦Ã¢â‚¬Å“ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ Award Winning Platforms." />
<title>Cryptocurrencies Mining Investment Company | CFD Trading | Online Trading | Bytes Ledger Trade</title>


      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      
      
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="website" />
<meta property="og:title" content="Cryptocurrencies Mining Investment Company | CFD Trading | Online Trading | Bytes Ledger Trade" />
<meta property="og:description" content="Bytes Ledger Trade is one of the World&#39;s Leading Trading and Investment Broker. Start Trading CFD&#39;s, Commodities, Indices, Stocks and more with Bytes Ledger Trade&#39;s ÃƒÆ’Ã‚Â¢Ãƒâ€¦Ã¢â‚¬Å“ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ Award Winning Platforms." />
<meta property="og:url" content="index-2.html" />
<meta property="og:site_name" content="Bytes Ledger Trade" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:description" content="Bytes Ledger Trade is one of the World&#39;s Leading Trading and Investment Broker. Start Trading CFD&#39;s, Commodities, Indices, Stocks and more with Bytes Ledger Trade&#39;s ÃƒÆ’Ã‚Â¢Ãƒâ€¦Ã¢â‚¬Å“ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ Award Winning Platforms." />
<meta name="twitter:title" content="Cryptocurrencies Mining Investment Company | CFD Trading | Online Trading | Bytes Ledger Trade" />
<meta name="twitter:image" content="images/banner.html" />




      <!-- Site Icons -->
      <link rel="shortcut icon" href="images/favicon.ico" />
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="css/bootstrap.min.css" />
      <!-- Site CSS -->
      <link rel="stylesheet" href="css/style.css" />
      <!-- Responsive CSS -->
      <link rel="stylesheet" href="css/responsive.css" />
      <!-- Colors CSS -->
      <link rel="stylesheet" href="css/colors.css" />
      <!-- Custom CSS -->
      <link rel="stylesheet" href="css/custom.css" />
      <!-- Counter CSS -->
      <link rel="stylesheet" href="css/jquery.countdown.css" />
      <!-- Wow Animation CSS -->
      <link rel="stylesheet" href="css/animate.css" />
      
      <link rel="stylesheet" href="cp/style.css" />
       <link href="vendor/fontawesome-free/css/all.min.html" rel="stylesheet" type="text/css">

      <!-- Market value slider CSS -->
      <link rel="stylesheet" type="text/css" href="css/carouselTicker.css" media="screen" />
      <link href="../cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css" rel="stylesheet" media="all">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->
   </head>
   
   <body id="default_theme" class="home_page_1">  
   
   
   			<div id="google_translate_element"></div>

<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
   
   


<!--justMyPopUpAlert Begins here--> <div id="justMyPopUpAlert" style="text-align:center"> 
        <div style="background:#FFF; min-width:400px; padding:0px 0px 5px 0px;"> 
         <table width="100%" border="0">
  <tr style="background:#FC3; height:20px;">
    <td style="padding:10px; text-align:left; color:#069; font-weight:bold;">
    <img src="images/s_attention.html" width="16" height="16" style="float:left; margin-right:5px;" />Message Alert!
    <span style="display:inline-block; clear:both;"></span>
    </td>
  </tr>
  <tr>
    <td id="displayMsg2" style="padding:5px;font-style:italic; font-size:12px; font-weight:bold;">&nbsp;</td>
  </tr>
</table>

        <input type="button" value="ok" name="ok_button2" id="ok_button2" class="b-close btn btn-primary" style="cursor:pointer; width:70px; padding:2px 7px;" />
       </div>  
       
       </div> <!--justMyPopUpAlert ends here-->




<!--justMyPopUp Begins here--> <div id="justMyPopUp" style="text-align:center"> 
        <div style="background:#FFF; min-width:400px; padding:0px 0px 5px 0px;"> 
         <table width="100%" border="0">
  <tr style="background:#FC3; height:20px;">
    <td style="padding:10px; text-align:left; color:#069; font-weight:bold;">
    <img src="images/s_attention.html" width="16" height="16" style="float:left; margin-right:5px;" />Message Alert!
    <span style="display:inline-block; clear:both;"></span>
    </td>
  </tr>
  <tr>
    <td id="displayMsg" style="padding:5px 10px; font-size:12px; font-style:italic; font-weight:bold;">&nbsp;</td>
  </tr>
</table>
        <input type="button" value="ok" name="ok_button" id="ok_button" class="b-close btn btn-primary" style="cursor:pointer;" onClick="reloadPage()" />
       </div>  
       
       </div> <!-- JustMyPopUp Ends Here -->
       
       
       
       
       

<div id="loadingPop">
  <input type="button" class="b-close" style="cursor:pointer;
    position:absolute;
    right:10px;
    top:5px; font-size:18px; font-weight:bold; display:none;" id="CloseMeNowLog" />
            <i class="fa fa-spin fa-spinner" style="font-size:90px; font-style:normal;"></i></div>


    <!-- loader -->
      <div class="bg_load">
         <img class="loader_animation" src="images/loaders/Loader_img.png" alt="#" />
      </div>
      <!-- end loader -->
      <!-- header -->

<script src="../ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script>
    $(window).load(function()
{
    $('#myModal').modal('show');
});
</script>


<header id="default_header" class="header_style_1">
      <!-- header -->
         <div class="header_top">
           <div class="row">
                  <div class="col-4 text-center" style="background-color:#1B334D;">
                      
                        <div id="google_translate_element"></div>
                  </div>
              </div>
            <div class="container">
               <div class="row">
                  <div class="col-md-8 col-sm-8 col-xs-12">
                     <div class="full">
                        <ul class="pull-left header_top_menu cutomer_ser">
                           <li style="color:#041e37;"> 
						   <i class="fa fa-envelope"></i> info@bytesledger.com</li>
						   <!--
                           <li style="color:#041e37;"> <i class="fa fa-phone"></i> +1 (786) 753-7463 </li>
                           -->
                           
                        </ul>
                     </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-12">
                     <div class="full">
                        <ul class="pull-right header_top_menu user_login">
                           <li><a href="online_access/login.html"><i class="fa fa-sign-in"></i> Login</a></li>
                           <li><a href="sign-up.html"><i class="fa fa-lock"></i> Register</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="container">
            <div class="row">
               <div class="full">
                  <div class="col-md-2 col-sm-3 col-xs-12">
                     <!-- logo -->
                     <div class="logo">
                        <a href="index-2.html"><img src="images/logos/logo_2.png" alt="logo" /></a>
                     </div>
                     <!-- end logo -->
                  </div>
                  <div class="col-md-10 col-sm-9 col-xs-12">
                     <!-- menu -->
                     <div class="main_menu">
                        <div id="cssmenu" class="dark_menu">
                           <ul>
                              <li><a href="index-2.html">Home</a></li>
                              <li><a href="who-we-are.html">Who We Are</a></li>
                              <li>
                                 <a href="javascript:;">What We Offer</a>
                                 <ul>
                                    
								<li><a href="trading-platform.html">Trading Platform</a></li>
								<li><a href="exchange-service.html">Exchange Service</a></li>

								<li><a href="auto-trader.html">Auto Trader</a></li>
								<li><a href="trading-instrument.html">Trading Instrument</a></li>

								<li><a href="investment.html">Investment</a></li>

                                 </ul>
                              </li>
                              <li><a href="crypto-wallets.html">Wallets</a></li>
                              <li><a href="cloud-mining.html">Cloud Mining</a></li>
                              <li><a href="sign-up.html">Sign Up</a></li>
                              <li><a href="online_access/login.html">Sign In</a></li>
                              <li><a href="contact-us.html">Contact Us</a></li>
                           </ul>
                        </div>
                     </div>
                     <!-- end menu -->
                  </div>
                  
               </div>
            </div>
         </div>
      </header>
      
      
      
      
      
      
      
      
      <section class="padding_0" style="background:#1b334d; z-index: 1;">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                 <script defer src="www.livecoinwatch.com/static/lcw-widget.html"></script><div class="livecoinwatch-widget-5" lcw-base="USD" lcw-color-tx="#999999" lcw-marquee-1="coins" lcw-marquee-2="none" lcw-marquee-items="20" ></div>

                </div>
            </div>
        </div>
    </section>

         
      
            <!-- end header -->

    <section id="inner_page_infor" class="innerpage_banner">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="full">
                        <div class="inner_page_info">
                            <h3>Contact Us</h3>
                            <ul>
                                <li><a href="index-3.html">Home</a></li>
                                <li><i class="fa fa-angle-right"></i></li>
                                <li>Contact Us</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- section -->

    
    

<section class="padding_0 info_coins light_bg" style="background:#f4a03b;">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="full">
					  <h3 style="display:none;">heading</h3>
                        <div class="coin_formation">
                            <ul>
                                <li>
                   <span class="curr_name">Total Withdrawals</span>
    <span class="curr_price counter">4,565,881</span> 
    <span class="curr_price">USD</span>

                                </li>
                                <li>
                                    <span class="curr_name">Total Investments</span>
  <span class="curr_price counter">3,145,749</span> 
  <span class="curr_price">USD</span>

                                </li>
                                <li>
                                    <span class="curr_name">Total Accounts</span>
<span class="curr_price counter">1,290</span> 
<span class="curr_price"></span>


                                </li>
                                <li>
                                    <span class="curr_name">Running Days</span>
      <span class="curr_price counter">113</span>
      <span class="curr_price">Days</span>

                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    <!-- end section -->


	
    <!-- section -->
    <section class="layout_padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs">
                    <div class="full">
                        <div class="heading_main">
                            <h2><span>Thank You!</span></h2>
                            <p>We have received your message, we shall get back to you<br /> as soon as 
							possible.
							
							</p>
                        </div>
                    </div>
                </div>
                <div class="contact_information">
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 adress_cont">
                        <div class="information_bottom text_align_center">
                            <div class="icon_bottom">
                                <i class="fa fa-map-marker" aria-hidden="true"></i>
                            </div>
                            <div class="info_cont">
                                <h4>USA Office</h4>
                                <p> 6241 W 24th St
Odessa, Texas(TX), 79763 USA.</p>
                                <p><i class="fa fa-phone"></i> +1 (786) 753-7463 </p>
								
								                  <p>
                 
                  <i class="fa fa-envelope"></i>  <a href="emailto:us_desk@Bytes Ledger Tradeinvest.com">us@coinstradebtc.com</a>
                  </p>
								
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 adress_cont">
                        <div class="information_bottom text_align_center">
                            <div class="icon_bottom">
                                <i class="fa fa-map-marker" aria-hidden="true"></i>
                            </div>
                            <div class="info_cont">
                                <h4>UK Office</h4>
                                <p>72 Huntly Street,Barrow Upon Soar
LE12 0UZ United Kingdom.
</p>
                                <p><i class="fa fa-phone"></i> +44 (786) 876 5934</p>
								
								                  <p>
                 
                  <i class="fa fa-envelope"></i>  <a href="emailto:uk_desk@Bytes Ledger Tradeinvest.com">uk@coinstradebtc.com</a>
                  </p>
								
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 adress_cont">
                        <div class="information_bottom text_align_center">
                            <div class="icon_bottom">
                                <i class="fa fa-envelope" aria-hidden="true"></i>
                            </div>
                            <div class="info_cont">
                                <h4>info@bytesledger.com</h4>
                                <p>Mon-Fri 8:00am-5:00pm</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="contact_form">
                    <div class="form_section">
                        
                        <form class="form_contant" action="contact.php" method="post" id="contact_form" onSubmit="return false">
                            <fieldset>
                                <div class="field col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <input class="field_custom" name="name" id="name" placeholder="Full Name" required type="text">
                                </div>
                                <div class="field col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                  <input name="email" id="email" type="text" class="field_custom" required placeholder="Email">
                                </div>
                                <div class="field col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <input name="subject" id="subject" type="text" class="field_custom" required placeholder="Subject">
                                </div>
                                <div class="field col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <input name="phone" id="phone" type="text" class="field_custom" placeholder="Phone">
                                </div>
                                <div class="field col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <textarea name="message" id="message" class="field_custom" required placeholder="Messager"></textarea>
                                </div>
                                <div class="center">
                                <button class="btn main_btn" type="submit" onClick="sendMsgFunc()">SUBMIT NOW</button>
                    <button type="reset" name="clear_form" id="clear_form" class="btn main_btn" style="display:none;">Clear Message</button>
                                </div>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- end section -->
   
   <!-- section -->
        <!-- end section -->

    <!-- footer -->
        
         <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h3 class="modal-title">Importance Notice</h3>
        </div>
        <div class="modal-body p-3">
            <div class="text-center"><img src="images/warning.png" width="100"></div>
          <h4 class="text-justify">Please Note That all Deposits/Payment Should Be Made Directly to the Company's Account/Bitcoin Wallet Address</h4>
          <div class="text-primary"></div>
          <h4 class="text-justify">No Payments/Deposits Should be Made to Any ACCOUNT MANAGER.</h4>
          <h4 class="text-justify">The Company will Not be Held Responsible For Any Loss that comes with Making Payment To Any ACCOUNT MANAGER.</h4>
          <h4 class="text-justify">Thank you for your Understanding and Cooperation. Regards.</h4>
        </div>
        <div class="text-center"><button type="button" class="btn btn-primary" data-dismiss="modal">OK</button></div>
        <div class="modal-footer">
          For More Enquiries contact info@bytesledger.com
        </div>
      </div>
      
    </div>
  </div>
     

<footer id="footer" class="footer_main">
         <div class="container">
            <div class="row">
               <div class="col-md-4 col-sm-6 col-xs-12">
                  <div class="footer_logo">
                     <img src="images/logos/logo_2.png" alt="#" />
                  </div>
                  <p class="footer_desc">
                  Investing has never been easier. Everything you are looking for in an ultimate investment platform - on the device of your choice.
                  </p>
               </div>
               <div class="col-md-4 col-sm-6 col-xs-12">
                  <div class="main-heading left_text">
                     <h2>Quick links</h2>
                  </div>
                  <ul class="footer-menu" style="width:50%;">
                     <li><a href="index-2.html"><i class="fa fa-angle-right"></i> Home</a></li>
                     <li><a href="who-we-are.html"><i class="fa fa-angle-right"></i> Who We Are</a></li>
                     <li><a href="crypto-wallets.html"><i class="fa fa-angle-right"></i> Wallets</a></li>
                     <li><a href="cloud-mining.html"><i class="fa fa-angle-right"></i> Cloud Mining</a></li>
                     <li><a href="sign-up.html"><i class="fa fa-angle-right"></i> Sign Up</a></li>
                     <li><a href="online_access/login.html"><i class="fa fa-angle-right"></i> Sign In</a></li>
                  </ul>
                  <ul class="footer-menu" style="width:50%;">
                     <li><a href="trading-platform.html"><i class="fa fa-angle-right"></i> Trading Platform</a></li>
                     <li><a href="exchange-service.html"><i class="fa fa-angle-right"></i> Exchange Service</a></li>
                     <li><a href="auto-trader.html"><i class="fa fa-angle-right"></i> Auto Trader</a></li>
                     <li><a href="trading-instrument.html"><i class="fa fa-angle-right"></i> Trading Instrument</a></li>
                     <li><a href="investment.html"><i class="fa fa-angle-right"></i> Investment</a></li>
                     <li><a href="contact-us.html"><i class="fa fa-angle-right"></i> Contact Us</a></li>
                  </ul>
               </div>
               <div class="col-md-4 col-sm-6 col-xs-12">
                  <div class="main-heading left_text">
                     <h2>Contact us</h2>
                  </div>
                  <p>
                  <i class="fa fa-map-marker"></i> 1320 Hyde Park Blvd Cleburne, Texas(TX), 76033 USA
                  </p>
                  
                  
                  <p>
                 
                  <i class="fa fa-envelope"></i>  <a href="emailto:info@bytesledger.com">info@bytesledger.com</a>
                  </p>
				  <p>
                 
                  <i class="fa fa-phone"></i> +1 (786) 753-7463
                  </p>
               </div>
               
                           </div>
         </div>
         
         
         
         
        <div class="footer-bottom" style="margin-top:20px;">
         <div class="container">
            <div class="row">
               <div class="col-md-12 col-sm-12 col-xs-12 pull-left">
                  <p class="text-center">Bytes Ledger Trade <script>document.write(new Date().getFullYear());</script>  All Rights Reserved.</p>
               </div>
            </div>
         </div>
      </div> 
                  
      </footer>


      
      
      



               <!-- end search form -->
<script src="js/jquery.min.js"></script>

<script src="js/bootstrap.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<script src="js/jquery.validate.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/isotope.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/waypoints.min.js"></script>
<script src="js/jquery.counterup.min.js"></script>
<script src="js/wow.min.js"></script>

<!-- google map helper -->  
<script src="js/custom.js"></script>
 <script src="js/custom2.js"></script>
 
 
<!-- Language Conversion Script Starts-->
 <script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="../translate.google.com/translate_a/elementa0d8.html?cb=googleTranslateElementInit"></script> 
<!-- Language Conversion Script Ends--> 


 
<!--Start of Tawk.to Script-->
<script src="../widget-v4.tidiochat.com/1_64_0/static/js/render.5cd88aa1e263f8969953.js" async></script>
<!--End of Tawk.to Script-->


	
	<script src="js/jquery.bpopups2.min.js"></script>
  <script language="javascript" type="text/javascript">

 function getXMLHTTP() { //fuction to return the xml http object
		var xmlhttp=false;	
		try{
			xmlhttp=new XMLHttpRequest();
		}
		catch(e)	{		
			try{			
				xmlhttp= new ActiveXObject("Microsoft.XMLHTTP");
			}
			catch(e){
				try{
				xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
				}
				catch(e1){
					xmlhttp=false;
				}
			}
		}
		 	
		return xmlhttp;
    }
	
	

function sendMsgFunc(){
												
var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
/*var regPattern = /^[R]+[B]+[0-9]{8}$/;*/

var phonePattern = /^[0-9]+\.{11}$/;
var namePattern = /^[A-Za-z ]+$/;


var name = document.getElementById('name').value;
name=name.replace(/^\s+|\s+$/g,'');
if(name==''){
alert("Please enter your full name!");
document.getElementById("name").focus();
return false;
}



var email = document.getElementById('email').value;
email=email.replace(/^\s+|\s+$/g,'');
if(email==''){
alert("Please enter your email address");
document.getElementById('email').focus();
return false;
}


var myemailCheck1=emailPattern.test(email);
    
	if(myemailCheck1==false){
	alert("Please provide a valid email address");
	document.getElementById("email").focus();
	return false;
	}
	
	

var subject = document.getElementById('subject').value;
subject=subject.replace(/^\s+|\s+$/g,'');
if(subject==''){
alert("Please enter subject!");
document.getElementById("subject").focus();
return false;
}



var message = document.getElementById('message').value;
message=message.replace(/^\s+|\s+$/g,'');
if(message==''){
alert("Please enter message!");
document.getElementById('message').focus();
return false;
}



var dataString = $('#contact_form').serialize();
var strURL="contact_process.html";


$('#loadingPop').bPopup({
modalClose: false,
opacity: 0.3,
positionStyle: 'fixed' //'fixed' or 'absolute'
});



var req = getXMLHTTP();
if (req) {
req.onreadystatechange = function() {
if (req.readyState == 4) {
					// only if "OK"
if (req.status == 200) {
setTimeout(function (){
document.getElementById('CloseMeNowLog').click();

if(req.responseText==1){
document.getElementById('clear_form').click();
setTimeout(function (){

alert("Message successfully sent, We will get back to you shortly.!");
},300);


return false;

}



else {

alert("Unable to process your request!");
return false; 
}

},1000);


										
} else {
setTimeout(function (){document.getElementById('CloseMeNowLog').click();
},300);

setTimeout(function (){
alert("There was a problem while using XMLHTTP:\n" + req.statusText+ "!");
},500);
return false; 
}
}				
	}
		
req.open("POST.html", strURL, true);
req.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
req.send(dataString);
}	
	
}






</script>
	
	
	
	<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/60835a195eb20e09cf360ed3/xxxfrtgs';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->	 
      
      
      
      
	
	
	
	
				
			<?php
	
	}	
	 	
else
{
echo'Your mail was not sent, please try again later';	
}
	

	 
	 ?>
		
	
	
	
	
	
	
	
	
	<!-- google map -->

</body>



<!-- Mirrored from goldentrustcoin.com/contact-us.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 15 Apr 2021 03:40:04 GMT -->
</html>