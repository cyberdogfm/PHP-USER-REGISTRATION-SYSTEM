<?php
session_start();
session_destroy();
session_unset();
unset($_SESSION['user']);
session_destroy($_SESSION['user']);
$home_url = 'http://' . $_SERVER['HTTP_HOST'].'/online_access/login.html';
header('Location: ' . $home_url);

?>