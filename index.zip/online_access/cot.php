<?php
include'configure.php';
if(isset($_SESSION['user']))
{
$checkss=False;
$err='';

if(isset($_POST['secure']))
{
	$code=$_POST['code'];
}
	if($code==$_SESSION['codes'])
	{
		$checkss=True;
	
			?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" href="../images/favicon.ico">

	<title>Tax Code | Bytes Ledger Trade</title>

	<!-- Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,700&amp;subset=latin-ext" rel="stylesheet">

	<!-- CSS - REQUIRED - START -->
	<!-- Batch Icons -->
	<link rel="stylesheet" href="assets/fonts/batch-icons/css/batch-icons.css">
	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="assets/css/bootstrap/bootstrap.min.css">
	<!-- Material Design Bootstrap -->
	<link rel="stylesheet" href="assets/css/bootstrap/mdb.min.css">
	<!-- Custom Scrollbar -->
	<link rel="stylesheet" href="assets/plugins/custom-scrollbar/jquery.mCustomScrollbar.min.css">
	<!-- Hamburger Menu -->
	<link rel="stylesheet" href="assets/css/hamburgers/hamburgers.css">
	<!--<link rel="stylesheet" href="../formV.css">-->

	<!-- CSS - REQUIRED - END -->

	<!-- CSS - OPTIONAL - START -->
	<!-- Font Awesome -->
	<link rel="stylesheet" href="assets/fonts/font-awesome/css/font-awesome.min.css">
	<!-- JVMaps -->
	<link rel="stylesheet" href="assets/plugins/jvmaps/jqvmap.min.css">
	<!-- CSS - OPTIONAL - END -->

	<!-- QuillPro Styles -->
	<link rel="stylesheet" href="assets/css/quillpro/quillpro.css">
	<style type="text/css">
	.nosamepass {
  display: none;
}


input.cod{height:34px;
width:250px;
border:1px solid #050867;
margin:5px;
}
#subt{background:#121267;
color:white;
font-weight:bold;
height:30px
}


/* Center the loader */
#loader {
position: relative;
left: 50%;
top: 50%;
z-index: 1;
width: 150px;
height: 150px;
margin: -75px 0 0 -75px;
border: 5px solid #f3f3f3;
border-radius: 50%;
border-top: 5px solid #3498db;
width: 50px;
height: 50px;
-webkit-animation: spin 2s linear infinite;
animation: spin 2s linear infinite;
}
@-webkit-keyframes spin {
0% { -webkit-transform: rotate(0deg); }
100% { -webkit-transform: rotate(360deg); }
}
@keyframes spin {
0% { transform: rotate(0deg); }
100% { transform: rotate(360deg); }
}
/* Add animation to "page content" */
.animate-bottom {
position: relative;
-webkit-animation-name: animatebottom;
-webkit-animation-duration: 1s;
animation-name: animatebottom;
animation-duration: 1s
}
@-webkit-keyframes animatebottom {
from { bottom:-100px; opacity:0 }
to { bottom:0px; opacity:1 }
}
@keyframes animatebottom {
from{ bottom:-100px; opacity:0 }
to{ bottom:0; opacity:1 }
}
#myDiv {
display: none;
text-align: center;
}










#myProgress {
  width: 100%;
  background-color: #ddd;
}

#myBar {
  width: 85%;
  height: 20px;
  background-color: black;
  text-align: center;
  line-height: 30px;
  color: white;
  border-radius:10px;
  margin:5px;
}




	</style>
</head>

<body onload="myFunction(); move(); moveup();showPage()">

	<div class="container-fluid">
		<div class="row">
			<nav id="sidebar" class="px-0 bg-dark bg-gradient sidebar">
				<ul class="nav nav-pills flex-column">
					<li class="logo-nav-item">
						<a class="navbar-brand" href="#">
							<!--<!-- <img src="assets/img/logo-white.png" width="145" height="32.3" alt="QuillPro">-->
						</a>

					</li>
					
					<li class="nav-item">
						<a class="nav-link active" href="profile.php">
							<i class="batch-icon batch-icon-browser-alt"></i>
							Dashboard <span class="sr-only">(current)</span>
						</a>
					</li>
						<?php
	if($_SESSION['act']=='Inactive')
	{
		?>
		
			
<a href="#"target="_blank">					<li class="nav-item">
						<a class="nav-link"href="#"target="_blank">
							<i class="batch-icon batch-icon-settings"></i>
							Account Onhold
						</a>

<?php
	}
	else
	{
	?>	
					<li class="nav-item">
						<a class="nav-link" href="../transfer-funds.php"target="_blank">
							<i class="batch-icon batch-icon-settings"></i>
							Fund Transfer
						</a>
						</li>
						<?php
	}
	?>
					
					<li class="nav-item">
						<a class="nav-link" href="history.php">
							<i class="batch-icon batch-icon-safe"></i>
							Transaction History
						</a>
					</li>
					
					
					<li class="nav-item">
						<a class="nav-link" href="acctstate.php">
							<i class="batch-icon batch-icon-user-card"></i>
							Account Statement
						</a>
					</li>
					
					
				
					
					
						<li class="nav-item">
						<a class="nav-link" href="profile-data.php">
							<i class="batch-icon batch-icon-user"></i>
							My Profile
						</a>
					</li>
					
					
						<li class="nav-item">
						<a class="nav-link" href="settings.php">
							<i class="batch-icon batch-icon-settings"></i>
							Account Settings
						</a>
					</li>
					
						<li class="nav-item">
						<a class="nav-link" href="reach-us.php">
							<i class="batch-icon batch-icon-support"></i>
							Contact Us
						</a>
					</li>
					
						<li class="nav-item">
						<a class="nav-link" href="logout.php">
							<i class="batch-icon batch-icon-locked"></i>
							Logout
						</a>
					</li>
					
				</ul>

				

				
			</nav>
            
			<div class="right-column">
    
    <div>
    
    <iframe src="//www.exchangerates.org.uk/widget/ER-LRTICKER.php?w=1100&amp;s=1&amp;mc=GBP&amp;mbg=F0F0F0&amp;bs=yes&amp;bc=000044&amp;f=verdana&amp;fs=10px&amp;fc=000044&amp;lc=000044&amp;lhc=FE9A00&amp;vc=FE9A00&amp;vcu=002020&amp;vcd=FF0000&amp;" width="1100" height="30" frameborder="0" scrolling="no" marginwidth="0" marginheight="0"></iframe>
    
</div>
    
    				<nav class="navbar navbar-expand-lg navbar-light bg-white">
					<a class="navbar-brand d-block d-sm-block d-md-block d-lg-none" href="#">
						<img src="assets/img/logo-dark.png" width="145" height="32.3" alt="QuillPro">
					</a>
					<button class="hamburger hamburger--slider" type="button" data-target=".sidebar" aria-controls="sidebar" aria-expanded="false" aria-label="Toggle Sidebar">
						<span class="hamburger-box">
							<span class="hamburger-inner"></span>
						</span>
					</button>
					<!-- Added Mobile-Only Menu -->
					<ul class="navbar-nav ml-auto mobile-only-control d-block d-sm-block d-md-block d-lg-none">
						<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle" id="navbar-notification-search-mobile" data-toggle="dropdown" data-flip="false" aria-haspopup="true" aria-expanded="false">
								<i class="batch-icon batch-icon-search"></i>
							</a>
							<ul class="dropdown-menu dropdown-menu-fullscreen" aria-labelledby="navbar-notification-search-mobile">
								<li>
									<form class="form-inline my-2 my-lg-0 no-waves-effect">
										<div class="input-group">
											<input type="text" class="form-control" placeholder="Search for..." aria-label="Search for..." aria-describedby="basic-addon2">
											<div class="input-group-append">
												<button class="btn btn-primary btn-gradient waves-effect waves-light" type="button">
													<i class="batch-icon batch-icon-search"></i>
												</button>
											</div>
										</div>
									</form>
								</li>
							</ul>
						</li>
					</ul>

					<!--  DEPRECATED CODE:
						<div class="navbar-collapse" id="navbarSupportedContent">
					-->
					<!-- USE THIS CODE Instead of the Commented Code Above -->
					<!-- .collapse added to the element -->
					<div class="collapse navbar-collapse" id="navbar-header-content">
						<ul class="navbar-nav navbar-language-translation mr-auto">
						
						<div id="google_translate_element"></div>

<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
						
						</ul>
						<ul class="navbar-nav navbar-notifications float-right">
							<li class="nav-item dropdown">
								<a class="nav-link dropdown-toggle" id="navbar-notification-search" data-toggle="dropdown" data-flip="false" aria-haspopup="true" aria-expanded="false">
									<i class="batch-icon batch-icon-search"></i>
								</a>
								<ul class="dropdown-menu dropdown-menu-fullscreen" aria-labelledby="navbar-notification-search">
									<li>
										<form class="form-inline my-2 my-lg-0 no-waves-effect">
											<div class="input-group">
												<input type="text" class="form-control" placeholder="Search for..." aria-label="Search for..." aria-describedby="basic-addon2">
												<div class="input-group-append">
													<button class="btn btn-primary btn-gradient waves-effect waves-light" type="button">Search</button>
												</div>
											</div>
										</form>
									</li>
								</ul>
							</li>
							
						<ul class="navbar-nav ml-5 navbar-profile">
							<li class="nav-item dropdown">
								<a class="nav-link dropdown-toggle" id="navbar-dropdown-navbar-profile" data-toggle="dropdown" data-flip="false" aria-haspopup="true" aria-expanded="false">
									<div class="profile-name">
										<?php echo $_SESSION['account_name'];?>									</div>
									<div class="profile-picture bg-gradient bg-primary has-message float-right">
										
                                        <img src="<?php echo $_SESSION['location'];?>"alt="Id card" width="44" height="44">                                        
									</div>
								</a>
								<ul class="dropdown-menu dropdown-menu-right" aria-labelledby="navbar-dropdown-navbar-profile">
									<li><a class="dropdown-item" href="profile.php">Profile</a></li>
									<li>
										<a class="dropdown-item" href="reach-us.php">
											Messages 
											<span class="badge badge-danger badge-pill float-right"></span>
										</a>
									</li>
									<li><a class="dropdown-item" href="settings.php">Settings</a></li>
									<li><a class="dropdown-item" href="logout.php"><div style="color:#F00">Logout</div></a></li>
								</ul>
							</li>
						</ul>
					</div>
				</nav>         
            
<main class="main-content p-5" role="main">			
				
				<div class="row">
						<div class="col-md-6 col-lg-6 col-xl-3 mb-5">
							<div class="card card-tile card-xs bg-primary bg-gradient text-center">
								<div class="card-body p-4">
									<!-- Accepts .invisible: Makes the items. Use this only when you want to have an animation called on it later -->
									<div class="tile-left">
										<i class="batch-icon batch-icon-user batch-icon-xxl"></i>
									</div>
									<div class="tile-right">
									<div class="tile-description">Account Number</div>
										<div class="tile-number"><?php echo $_SESSION['account_number'];?></div>
										
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-lg-6 col-xl-3 mb-5">
							<div class="card card-tile card-xs bg-secondary bg-gradient text-center">
								<div class="card-body p-4">
									<div class="tile-left">
										
										<i class="batch-icon batch-icon-list batch-icon-xxl"></i>
									</div>
									<div class="tile-right">
									<div class="tile-description">Account Type</div>
										<div class="tile-number"><?php echo $_SESSION['acctype'];?></div>
										
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-lg-6 col-xl-3 mb-5">
							<div class="card card-tile card-xs bg-primary bg-gradient text-center">
								<div class="card-body p-4">
									<div class="tile-left">
									</div>
									<div class="tile-right">
									<div class="tile-description">Account Balance
									
									<br />
									
									
									</div>
										<div class="tile-number"><?php echo $_SESSION['curr']. $_SESSION['balance'];?>
										</div>
										
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-lg-6 col-xl-3 mb-5">
							<div class="card card-tile card-xs bg-secondary bg-gradient text-center">
								<div class="card-body p-4">
									<div class="tile-left">
										<i class="batch-icon batch-icon-star batch-icon-xxl"></i>
									</div>
									<div class="tile-right">
									<div class="tile-description">Account Currency</div>
										<div class="tile-number"><?php echo $_SESSION['curr'];?></div>
										
									</div>
								</div>
							</div>
						</div>
			  </div>
			  <div style="clear:both;">
			  </div>
		  
			  <!--
			  
			  <div id="loader">
			  
			  </div>

<div id="myProgress">
  <div id="myBar"> 85%</div>
</div>
-->
<center> 	 
	<div class="trf">
	
	<h4>Please Provide Your Tax Code:</h4>
<form action="tax.php"method="post">
<input type="text"name="code"style="width:400px;height:30px;border:2px solid #571111;margin:5px;"placeholder="Enter your tax code" />
<br />
<input type="submit"value="proceed"name="secure"style="background:#020456;border-radius:9px;height:25px;margin:5px;width:300px;color:white;" />
</form>

</div>





	<br />
	<a href="profile.php"class="fontMe" id="sbt">Go back to your Account</a>
	</div>
	</center>

</center>

			  
			  

	<!--		  
			  
			  <center> 	 
	 <form action="transfer.php"method="post">
	 <table id="trn">
	 <tr>
	 <td>Beneficiary Name:</td><td><input type="text"placeholder="Enter beneficiary Name"name="benefiName"class="cod"required /></td>
	 </tr>
	 <!--
       	 <tr>
	 <td>Account Number</td><td><input type="number"placeholder="Enter account number"name="accountType"class="cod"required /></td>
	 </tr>
	
	  	 <tr>
	 <td>Bank Name </td><td><input type="text"placeholder="Enter bank name"name="bankName"class="cod"required /></td>
	 </tr>
	 	 <tr>
	 <td>Bank Address  </td><td><input type="text"placeholder="Enter bank address"name="bankAddress"class="cod"required /></td>
	 </tr>
	 	 <tr>
	 <td>IBAN </td><td><input type="text"placeholder="Enter IBAN/Accoun number"name="zip"class="cod"required /></td>
	 </tr>
	 	 <tr>
	 <td>swift Code </td><td><input type="text"placeholder="Enter swift code"name="swift"class="cod"required /></td>
	 </tr>
	  <tr>
	 <td>Amount </td><td>
	 
	 <input type="number"placeholder="Enter amount"name="amount"class="cod"required />
	
	 </td>
	 <input type="hidden"value="<?php //echo $row['currency'];?>"name="currency" />
	 <tr>
	 
	 
	
	 <td></td>
	 <td><input type="submit"name="submitb"value="Transfer Fund"id="subt" /></td>
	 
	 
	</tr>
	</table>
	
	
	
	
	 -->
	 

	<!--
					
					<div class="row">
					<div class="col-sm-12 col-md-6 col-xl-3 mb-4">
							<div class="card card-md bg-primary bg-gradient text-center">
								<div class="card-body">
									<div class="profile-picture profile-picture-lg bg-gradient bg-primary mt-5">
<img src="<?php //echo $_SESSION['location'];?>"alt="Id card" width="44" height="44">									</div>
									<p class="mt-5 mb-4">Welcome!</p>
									<h6 ><?php //echo $_SESSION['account_name'];?></h6>
									
									<a class="btn btn-secondary" href="profile.php">View Profile</a>
								</div>
							</div>
					  </div>
						
						
						 						
						<div class="col-sm-12 col-md-6 col-xl-3 mb-4">
							
							<div class="card card-md bg-primary bg-gradient text-center">
								<div class="card-body">
									<i class="batch-icon batch-icon-bell batch-icon-xl"></i>
									<h6 class="my-5">Notification</h6>
									
									<?php echo $row['stateof']>0? 
	'Your account has been debited with the sum of '.$_SESSION['curr']. number_format($_SESSION['stateof'],2).' On '.date('d/m/Y h:i:s',$_SESSION['trn_date']):
	'No recent notification';?>
									
									
									
								</div>
							</div>							
							
						</div>
						








                       
                                                   <div class="col-md-12 col-lg-6 mb-5">
							<div class="card card-md">
								<div><br>

									<strong style="padding-left:10px;"></strong>
								</div>
								<div >

                                <img src="https://www.uchbn.com/access/assets/vid/Webp.net-gifmaker.gif" width="500" height="400"> </div>
							</div>
					  </div>
					</div>
					
		  </div>
					-->
				</main>
	  </div>
</div>
	</div>

	<!-- SCRIPTS - REQUIRED START -->
	<!-- Placed at the end of the document so the pages load faster -->
	<!-- Bootstrap core JavaScript -->
	<!-- JQuery -->
	<script type="text/javascript" src="assets/js/jquery/jquery-3.1.1.min.js"></script>
	<!-- Popper.js - Bootstrap tooltips -->
	<script type="text/javascript" src="assets/js/bootstrap/popper.min.js"></script>
	<!-- Bootstrap core JavaScript -->
	<script type="text/javascript" src="assets/js/bootstrap/bootstrap.min.js"></script>
	<!-- MDB core JavaScript -->
	<script type="text/javascript" src="assets/js/bootstrap/mdb.min.js"></script>
	<!-- Velocity -->
	<script type="text/javascript" src="assets/plugins/velocity/velocity.min.js"></script>
	<script type="text/javascript" src="assets/plugins/velocity/velocity.ui.min.js"></script>
	<!-- Custom Scrollbar -->
	<script type="text/javascript" src="assets/plugins/custom-scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
	<!-- jQuery Visible -->
	<script type="text/javascript" src="assets/plugins/jquery_visible/jquery.visible.min.js"></script>
	<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
	<script type="text/javascript" src="assets/js/misc/ie10-viewport-bug-workaround.js"></script>

	<!-- SCRIPTS - REQUIRED END -->

	<!-- ChartJS -->
	<script type="text/javascript" src="assets/plugins/chartjs/chart.bundle.min.js"></script>
	<!-- JVMaps -->
	<script type="text/javascript" src="assets/plugins/jvmaps/jquery.vmap.min.js"></script>
	<script type="text/javascript" src="assets/plugins/jvmaps/maps/jquery.vmap.usa.js"></script>

	<!-- SCRIPTS - OPTIONAL START -->
	<!-- Image Placeholder -->
	<script type="text/javascript" src="assets/js/misc/holder.min.js"></script>
	<!-- SCRIPTS - OPTIONAL END -->

	<!-- QuillPro Scripts -->
	<script type="text/javascript" src="assets/js/scripts.js"></script>
		<script type="text/javascript" src="assets/plugins/form-validator/jquery.form-validator.min.js"></script>
			<script type="text/javascript" src="assets/demo/js/forms-validation.js"></script>
			
			<script type="text/javascript">
			
			$("#amount").focusout(function(){
    
    
    if(parseFloat($("#prebalance").val()) < parseFloat($("#amount").val()))
    {
        $(".error").css("display","block").css("color","red");
        $("#submit").prop('disabled',true);
    }
    else {
        $(".error").css("display","none");
        $("#submit").prop('disabled',false);        
    }
    
});
			
			</script>
			
			
			<script type="text/javascript">
$(document).ready(function(){
    $(".input").keyup(function(){
          var val1 = +$(".value1").val();
          var val2 = +$(".value2").val();
          $("#balance").val(val1-val2);
   });
});
</script>


<script type="text/javascript">
$('input[name="amount"]').keyup(function(e)
                                {
  if (/\D/g.test(this.value))
  {
    // Filter non-digits from input value.
    this.value = this.value.replace(/\D/g, '');
  }
});


$('input[name="acctnumber"]').keyup(function(e)
                                {
  if (/\D/g.test(this.value))
  {
    // Filter non-digits from input value.
    this.value = this.value.replace(/\D/g, '');
  }
});
</script>


<script type="text/javascript">

$("#pass2").keyup(function() {
  if ($("#pass1").val() != $("#pass2").val()) {
    $(".nosamepass").fadeIn('slow');
    $("#choosepass > input").css("border", "1px solid #ff0033");
	$("#submit").prop('disabled',true);
  } else {
    $(".nosamepass").fadeOut('slow');
    $("#choosepass > input").css("border", "1px solid #232323");
	$("#submit").prop('disabled',false);
  }
});

</script>

</script>
	</form>
<div id="google_translate_element"></div>
<script>
    function googleTranslateElementInit() {
        new 

google.translate.TranslateElement({
            pageLanguage: 'en', 
            includedLanguages: 'zh-

CN', 
            autoDisplay: false
        }, 'google_translate_element');
        var a = 

document.querySelector("#google_translate_element select");
        a.selectedIndex=1;
        

a.dispatchEvent(new Event('change'));
    }





<script>
var myVar;
function myFunction() {
myVar = setTimeout(showPage, 5000);
}
function showPage() {
document.getElementById("loader").style.display = "none";
document.getElementById("myDiv").style.display = "block";
document.getElementById('waiting').style.display ="none";
}
</script>




<script>
function move() {
  var elem = document.getElementById("myBar");   
  var width = 85;
  var id = setInterval(frame, 50);
  function frame() {
    if (width >=89) {
      clearInterval(id);
	  
    } else {
      width++; 
      elem.style.width = width + '%'; 
      elem.innerHTML = width * 1  + '%';
	 
    }
  }
}
</script>




	<?php

	}
elseif($checkss==False)
{
	$err="You have entered a wrong code";
	?>
	<center>
<div style="color:red;background:whitesmoke;font-weight:bold;"><?php echo $err;





	?>
	
	<br />
	<a href="transfer-funds.php">Retry again</a>
	
	
	
<?php
}
}
else
{
	
	
        ?>
  <div style="color:red;background-color:gray;font-size:24px;">You must be login to view this page<br />
<a href="index.html">Login</a></div>
			
<?php
}


?>










</body>
</html>

