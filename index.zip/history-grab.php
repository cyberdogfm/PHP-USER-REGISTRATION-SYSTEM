<?php
 include'configure.php';
	 if(isset($_POST['historyOne']))
	
	 {
	$user= $_POST['user'];
	$historyOne=$_POST['historyOne'];
	$historyOneDate=$_POST['historyOneDate'];
	$historyOneDesc=$_POST['historyOneDesc'];
	$historyOneBalance=$_POST['historyOneBalance'];
	

	$type1=$_POST['types1'];
	
	
	
	$historyTwo=$_POST['historyTwo'];
	$historyTwoDate=$_POST['historyTwoDate'];
	$historyTwoDesc=$_POST['historyTwoDesc'];
	$historyTwoBalance=$_POST['historyTwoBalance'];
	
	$type2=$_POST['types2'];
	
	
	
	/*
	$security=$_POST['security'];
	if($security=='eddy123')
	{
		
		
	if (!isset($_FILES['userfile']['tmp_name']))
		{
	echo "";
	}
	$filetype=$_FILES['userfile']['type'];
	$allowed=array('image/jpeg','image/gif','image/png','image/jpg');
	if(! in_array($filetype,$allowed))
	{
		header("location:create.php?fileerror=$err");
		exit();
	}
	else{
	$file=$_FILES['userfile']['tmp_name'];
	$image= addslashes(file_get_contents($_FILES['userfile']['tmp_name']));
	$image_name= addslashes($_FILES['userfile']['name']);		
			move_uploaded_file($_FILES["userfile"]["tmp_name"],"photos/" . $_FILES["userfile"]["name"]);
			
			$location="photos/" . $_FILES["userfile"]["name"];
		$sq ='SELECT * from users WHERE username="'.$username.'"';
		$rresult = mysqli_query($conn,$sq);
		if(mysqli_num_rows($rresult)>0)
		{
			header('location:error-create.php');
			exit();
		}
		*/
		
		}
	
	
	
	
	if(mysqli_query($conn,'insert into history(usern,numone,numonedate,numonedesc, numonebalance,numonetype,numtwo,numtwodate,numtwodesc,numtwobalance,numtwotype) 
		values ("'.$user.'","'.$historyOne.'","'.$historyOneDate.'", "'.$historyOneDesc.'","'.$historyOneBalance.'","'.$type1.'","'.$historyTwo.'","'.$historyTwoDate.'","'.$historyTwoDesc.'","'.$historyTwoBalance.'","'.$type2.'")'))
	
					{
					
	
	
	
	/*
	if(mysqli_query($conn,'INSERT INTO history (usern,numone,numonedate,numonedesc,numonebalance,numonetype
	
	numtwo,numtwodate,numtwodesc,numtwobalance,numtwotype,numthree,numthreedate,numthreedesc,numthreebalance,numthreetype
	,numfour,numfourdate,numfourdesc,numfourbalance,numfourtype,numfive,numfivedate,numfivedesc,numfivebalance,numfivetype
	,numsix,numsixdate,numsixdesc,numsixbalance,numsixtype) 
		VALUES ("'.$user.'","'.$historyOne.'","'.$historyOneDate.'","'.$historyOneDesc.'","'.$historyOneBalance.'","'.$type1.'",
		"'.$historyTwo.'","'.$historyTwoDate.'","'.$historyTwoDesc.'","'.$historyTwoBalance.'","'.$type2.'",
		"'.$historyThree.'","'.$historyThreeDate.'","'.$historyThreeDesc.'","'.$historyThreeBalance.'","'.$type3.'",
		"'.$historyFour.'","'.$historyFourDate.'","'.$historyFourDesc.'","'.$historyFourBalance.'","'.$type4.'",
		"'.$historyFive.'","'.$historyFiveDate.'","'.$historyFiveDesc.'","'.$historyFiveBalance.'","'.$type5.'",
		"'.$historySix.'","'.$historySixDate.'","'.$historySixDesc.'","'.$historySixBalance.'","'.$type6.'")'))
	
					{
						*/
					
	?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">



<!-- Mirrored from www.uchbn.com/contact/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 16 Feb 2021 21:46:40 GMT -->
<head>
<meta http-equiv="Content-type" content="text/html;charset=UTF-8"><link rel="shortcut icon" href="Content/images/favicon.ico" />
	<title>Admin </title>
	
    
   
 



        

	
</head>

<body>
	<img height="1" width="1" style="border-style:none; display:none;" alt="" src=">

    <div id="ewb-wrapper">

        



<center>



	<a href="privateAdmin.php">Home</a>
	</center>
	
<div class="check">
	
	
	 <center>
	<?php

	echo'History Edited';
	?>
	</div>
	</center>
	
	<div style="visibility:hidden;margin:10px;">
	

	
	<!--Clear both -->
	</div>

	
	
	
	
	
	
<div class="clear"></div>
   
	
<?php
	
	}
		
		
		
	 	
else
{
echo'Error just occured';	
}
	
	
	
	 
	 ?>



</body>

</html>