<?php
$errr=$err2='';
if(isset($_GET['rc']))
{
$errr="Wrong Username or password";
	
}
	
?>
<!DOCTYPE html>

	<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" href="img/favicon.png">
		<!-- Author Meta -->
		<meta name="author" content="CyberDog web Intel.">
		<!-- Meta Description -->
		<meta name="description" content="Bytes Ledger Trade, best Forex trading broker">
		<!-- Meta Keyword -->
		<meta name="keywords" content="trade Bitcoin,Ethereum, USD,EURO ,online, digital currency,currency, money">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>Login</title>

		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
			<!--
			CSS
			============================================= -->
			<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="css/nice-select.css">					
			<link rel="stylesheet" href="css/animate.min.css">
			<link rel="stylesheet" href="css/owl.carousel.css">
			<link rel="stylesheet" href="css/main.css">
			<link rel="stylesheet" href="css/newstyle.css">
			<style>
.co{border:2px solid #235612;
height:35px;
width:350px;
border-radius:2px;
}
#regImage{width:80px;
height:110px;
}
.reg1{visibility:hidden;
}
#lo{background:#121667;
width:130px;
color:white;
font-weight:bold;
margin:10px;
height:40px;
}
			
			</style>
			
		</head>
		<body>

<div class="coverMe">
<h5 style="color:red;background:whitesmoke;width:400px;font-size:19px;"><?php echo $errr;
?></h5>
<center>
    
    <a href="index.html">Home</a><br />
    
			<div class="formReg">
			<form name="reg"action="privateAdmin.php"method="post">
			
		
	 Admin Username
	 <br />
	 <input type="text="name="username"class="co"placeholder="Enter your username"required />
	 <br />

	 <br />
	 Password
	 <br />
	 <input type="password"name="pass"class="co"placeholder="Enter your Password"required />
	 <br />
	
	  <input type="submit"name="btnn"id="lo"value="Login" />
	  </form>
	  </center>
</div>
			
			
			
			
			</div>
			




			
			<footer class="footer-area section-gap">
				
					
					
					<div class="footer-bottom d-flex justify-content-between align-items-center flex-wrap">
						<p class="footer-text m-0">
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Bytes Ledger Trade.
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
						</p>
						
			</footer>	
			<!-- End footer Area -->

			</center>
		</body>
	</html>



